const express = require('express');
const router = express.Router();
const SubBlock = require('../models/SubBlock');

// Get subblocks by building
router.get('/building/:buildingId', async (req, res) => {
  try {
    const blocks = await SubBlock.find({
      building: req.params.buildingId
    });
    res.json(blocks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;