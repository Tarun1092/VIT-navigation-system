const express = require('express');
const router = express.Router();

const navigationController = require('../controllers/navigationController');

router.get('/route', navigationController.getRoute);

module.exports = router;