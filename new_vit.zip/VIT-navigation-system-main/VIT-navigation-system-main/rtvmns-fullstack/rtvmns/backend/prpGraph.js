// backend/prpGraph.js

function calculateDistance(a, b) {
  return Math.sqrt(
    Math.pow(a.lat - b.lat, 2) +
    Math.pow(a.lng - b.lng, 2)
  );
}

/*
   We use the EXACT same coordinates
   as your frontend PRP segments.
   Then we calculate centroid of each polygon.
*/

const polygons = {

  blockE: [
    [12.972049947158158,79.16562438011171],
    [12.9719192592141,79.16552245616914],
    [12.971422644400384,79.16558951139451],
    [12.971433099459317,79.16588723659517],
    [12.97180164000572,79.16591405868532],
    [12.972002899506203,79.16573971509935]
  ],

  blockC1: [
    [12.971393892986088,79.16559219360353],
    [12.971299797425086,79.16561365127565],
    [12.971166495319421,79.16563242673875],
    [12.971090696051,79.16577458381653],
    [12.970949552524122,79.16578799486162],
    [12.97089204958281,79.16592746973039],
    [12.971048875755088,79.16606426239015],
    [12.971386051690684,79.1658891880417]
  ],

  blockC2: [
    [12.971634359258008,79.16662752628328],
    [12.971545491315023,79.16651219129564],
    [12.971430485694619,79.16653364896776],
    [12.971297183658988,79.16641294956209],
    [12.971213543129577,79.1663083434105],
    [12.970999214144571,79.16643172502519],
    [12.971048875755088,79.1665953397751],
    [12.971312866255127,79.16669726371767],
    [12.971548105078513,79.1666239500047]
  ],

  blockA: [
    [12.97234530165881,79.16662216186525],
    [12.97226166148183,79.16649341583252],
    [12.972104836074209,79.16650682687761],
    [12.971997671988767,79.166396856308],
    [12.971848687695742,79.16644513607027],
    [12.971783343679425,79.16662484407426],
    [12.97227473026135,79.1667938232422]
  ]
};


// --- centroid calculator ---
function centroid(coords) {
  let lat = 0;
  let lng = 0;

  coords.forEach(c => {
    lat += c[0];
    lng += c[1];
  });

  return {
    lat: lat / coords.length,
    lng: lng / coords.length
  };
}

// Build nodes from polygon centers
const nodes = Object.entries(polygons).map(([id, coords]) => {
  const center = centroid(coords);
  return {
    id,
    block: id,
    lat: center.lat,
    lng: center.lng
  };
});

const edges = [];

function connect(a, b) {
  const nodeA = nodes.find(n => n.id === a);
  const nodeB = nodes.find(n => n.id === b);

  const d = calculateDistance(nodeA, nodeB);

  edges.push({ from: a, to: b, distance: d });
  edges.push({ from: b, to: a, distance: d });
}

/*
   Force route order through segment centers
   EXACTLY matching your visual layout:

   blockA → blockC2 → blockC1 → blockE
*/

connect("blockA", "blockC2");
connect("blockC2", "blockC1");
connect("blockC1", "blockE");

module.exports = {
  nodes,
  edges
};