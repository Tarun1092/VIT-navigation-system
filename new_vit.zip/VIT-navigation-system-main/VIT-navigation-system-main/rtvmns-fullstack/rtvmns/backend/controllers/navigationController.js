// backend/prpGraph.js

function calculateDistance(a, b) {
  return Math.sqrt(
    (a.lat - b.lat) ** 2 +
    (a.lng - b.lng) ** 2
  );
}

function centroid(coords) {
  let lat = 0;
  let lng = 0;

  coords.forEach(c => {
    lat += c[0];
    lng += c[1];
  });

  return {
    lat: lat / coords.length,
    lng: lng / coords.length
  };
}

/*
  These are the SAME coordinates
  used in your frontend PRP segments.
*/

const segmentPolygons = {

  A: [
    [12.97234530165881,79.16662216186525],
    [12.97226166148183,79.16649341583252],
    [12.972104836074209,79.16650682687761],
    [12.971997671988767,79.166396856308],
    [12.971848687695742,79.16644513607027],
    [12.971783343679425,79.16662484407426],
    [12.97227473026135,79.1667938232422]
  ],

  C2a: [
    [12.971634359258008,79.16662752628328],
    [12.971545491315023,79.16651219129564],
    [12.971430485694619,79.16653364896776]
  ],

  C2b: [
    [12.971297183658988,79.16641294956209],
    [12.971213543129577,79.1663083434105],
    [12.970999214144571,79.16643172502519]
  ],

  Blue: [
    [12.971048875755088,79.1665953397751],
    [12.971312866255127,79.16669726371767],
    [12.971548105078513,79.1666239500047]
  ],

  C1: [
    [12.971393892986088,79.16559219360353],
    [12.971299797425086,79.16561365127565],
    [12.971166495319421,79.16563242673875]
  ],

  E: [
    [12.972049947158158,79.16562438011171],
    [12.9719192592141,79.16552245616914],
    [12.971422644400384,79.16558951139451]
  ]
};

const nodes = Object.entries(segmentPolygons).map(([id, coords]) => {
  const c = centroid(coords);
  return { id, lat: c.lat, lng: c.lng };
});

const edges = [];

function connect(a, b) {
  const A = nodes.find(n => n.id === a);
  const B = nodes.find(n => n.id === b);

  const d = calculateDistance(A, B);

  edges.push({ from: a, to: b, distance: d });
  edges.push({ from: b, to: a, distance: d });
}

/*
  Connect segments EXACTLY how layout flows
*/

connect("A", "C2a");
connect("C2a", "C2b");
connect("C2b", "Blue");
connect("Blue", "C1");
connect("C1", "E");


// simple helper maps used by both server and frontend
const PRP_CORRIDOR_PATH = [
  { lat: 12.97225, lng: 79.16668 },  // top of A
  { lat: 12.97205, lng: 79.16655 },
  { lat: 12.97175, lng: 79.16645 },
  { lat: 12.97145, lng: 79.16635 },
  { lat: 12.97120, lng: 79.16615 },  // blue segment
  { lat: 12.97105, lng: 79.16595 },
  { lat: 12.97135, lng: 79.16582 },
  { lat: 12.97165, lng: 79.16575 }   // block E
];

const BLOCK_COORDS = {
  blockE: { lat: 12.972049947158158, lng: 79.16562438011171 },
  blockC1: { lat: 12.971393892986088, lng: 79.16559219360353 },
  mainEntrance: { lat: 12.97107762720928,  lng: 79.16613131761552 },
  entrance: { lat: 12.97107762720928,  lng: 79.16613131761552 },
  blockC2: { lat: 12.971634359258008, lng: 79.16662752628328 },
  blockA: { lat: 12.97234530165881,  lng: 79.16662216186525 },
  blockF: { lat: 12.970886822042027, lng: 79.16639417409898 }
};

function findNearestCorridorIndex(coord) {
  let min = Infinity;
  let idx = 0;
  PRP_CORRIDOR_PATH.forEach((c, i) => {
    const d = Math.sqrt((coord.lat - c.lat) ** 2 + (coord.lng - c.lng) ** 2);
    if (d < min) { min = d; idx = i; }
  });
  return idx;
}

async function getRoute(req, res, next) {
  try {
    const { from, to } = req.query;
    if (!from || !to) {
      return res.status(400).json({ error: 'from and to required' });
    }

    // allow numeric corridor indices
    const parseCoord = (val) => {
      if (!isNaN(val)) {
        const n = parseInt(val, 10);
        if (n >= 0 && n < PRP_CORRIDOR_PATH.length) {
          return PRP_CORRIDOR_PATH[n];
        }
      }
      if (BLOCK_COORDS[val]) {
        return BLOCK_COORDS[val];
      }
      return null;
    };

    const startCoord = parseCoord(from);
    const endCoord   = parseCoord(to);

    if (!startCoord || !endCoord) {
      return res.status(404).json({ error: 'invalid from/to' });
    }

    // simple straight route for now: corridor slice
    const startIdx = findNearestCorridorIndex(startCoord);
    const endIdx   = findNearestCorridorIndex(endCoord);

    let path = [];
    if (startIdx <= endIdx) {
      path = PRP_CORRIDOR_PATH.slice(startIdx, endIdx + 1);
    } else {
      path = PRP_CORRIDOR_PATH.slice(endIdx, startIdx + 1).reverse();
    }

    // attach start and end points explicitly
    path[0] = startCoord;
    path[path.length - 1] = endCoord;

    res.json({ data: { route: { path } } });
  } catch (err) {
    next(err);
  }
}

module.exports = { nodes, edges, getRoute };
