const mongoose = require('mongoose');

// ─── Room Schema (FR5 - Building Intelligence) ────────────────────────────────
const roomSchema = new mongoose.Schema({
  // Identity
  roomNumber: {
    type: String,
    required: [true, 'Room number is required'],
    uppercase: true,
    trim: true   // e.g. "CSE204", "TT101", "GDN305"
  },
  name: { type: String, trim: true },   // e.g. "Digital Electronics Lab"
  type: {
    type: String,
    enum: ['classroom', 'lab', 'faculty_office', 'hod_office', 'seminar_hall',
           'auditorium', 'conference_room', 'library', 'washroom', 'staircase',
           'elevator', 'canteen', 'store', 'server_room', 'reception', 'other'],
    default: 'classroom'
  },
  

  // Location Reference (ER Diagram: Building 1 ←→ * Floor ←→ * Room)
  building: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Building',
    required: true
  },
  floor: { type: Number, required: true, min: 0 },
  floorLabel: { type: String, default: '' },  // "Ground Floor", "2nd Floor"

  // Physical Position (for indoor map rendering)
  position: {
    x: { type: Number, default: 0 },   // X pixel on floor plan SVG
    y: { type: Number, default: 0 },   // Y pixel on floor plan SVG
    width: { type: Number, default: 50 },
    height: { type: Number, default: 40 }
  },
  coordinates: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], default: [0, 0] }
  },
    // Outdoor Routing Mapping (PRP Graph Node)
  blockNodeId: {
    type: String,
    enum: [
      'blockE',
      'blockC1',
      'entrance',
      'blockF',
      'blockC2',
      'blockA'
    ],
    default: null
  },

  // Room Metadata (FR5.1 - POI Details)
  capacity: { type: Number, default: 0 },
  equipment: [{ type: String }],   // ['projector', 'AC', 'whiteboard', 'computers']
  description: { type: String, default: '' },

  // Faculty Link (FR5.3)
  facultyAssigned: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],

  // Real-time Status
  isOccupied: { type: Boolean, default: false },
  currentCourse: { type: String, default: '' },
  nextAvailableAt: { type: Date },

  // Timetable (simplified)
  schedule: [{
    day: { type: String, enum: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] },
    startTime: { type: String },
    endTime: { type: String },
    courseCode: { type: String },
    courseName: { type: String }
  }],

  // Accessibility
  isAccessible: { type: Boolean, default: true },
  isActive: { type: Boolean, default: true },
  isClosed: { type: Boolean, default: false },
  closureNote: { type: String, default: '' },

  // Tags for fuzzy search (FR2.1)
  tags: [{ type: String, lowercase: true }],
  aliases: [{ type: String }],    // Alternative names

  imageUrl: { type: String, default: '' },
  stats: {
    totalVisits: { type: Number, default: 0 }
  }

}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// ─── Virtual: Full Room Label ─────────────────────────────────────────────────
roomSchema.virtual('fullLabel').get(function () {
  return this.name ? `${this.roomNumber} - ${this.name}` : this.roomNumber;
});

// ─── Indexes ──────────────────────────────────────────────────────────────────
roomSchema.index({ building: 1, floor: 1 });
roomSchema.index({ roomNumber: 1, building: 1 }, { unique: true });
roomSchema.index({ roomNumber: 'text', name: 'text', tags: 'text', aliases: 'text' });
roomSchema.index({ coordinates: '2dsphere' }, { sparse: true });


// ─── PathSegment Schema (A* Pathfinding Graph - FR3.1) ────────────────────────
const pathSegmentSchema = new mongoose.Schema({
  // Graph Edge
  fromNode: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Room',
    required: true
  },
  toNode: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Room',
    required: true
  },

  // Edge Properties
  distanceMeters: { type: Number, required: true, min: 0 },
  estimatedTimeSeconds: { type: Number, required: true, min: 0 },
  pathType: {
    type: String,
    enum: ['corridor', 'staircase_up', 'staircase_down', 'elevator_up', 'elevator_down',
           'outdoor_path', 'ramp', 'bridge'],
    default: 'corridor'
  },

  // Route Scoring (for A* heuristics)
  isAccessible: { type: Boolean, default: true },
  isBidirectional: { type: Boolean, default: true },
  difficulty: {
    type: String,
    enum: ['easy', 'moderate', 'hard'],
    default: 'easy'
  },

  // Current Status
  isBlocked: { type: Boolean, default: false },
  blockageReason: { type: String, default: '' },
  blockageUntil: { type: Date },

  // Waypoints (for rendering the path on map)
  waypoints: [{
    x: Number,
    y: Number,
    floor: Number,
    instruction: String   // "Turn left at the pillar"
  }],

  building: { type: mongoose.Schema.Types.ObjectId, ref: 'Building' }

}, { timestamps: true });

pathSegmentSchema.index({ fromNode: 1, toNode: 1 });
pathSegmentSchema.index({ building: 1 });
pathSegmentSchema.index({ isBlocked: 1 });


// ─── Bookmark Schema (FR6.1) ──────────────────────────────────────────────────
const bookmarkSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  room: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Room',
    required: true
  },
  customName: { type: String, trim: true },   // "My Lab", "Prof. Sharma's Office"
  icon: { type: String, default: '📍' },
  color: { type: String, default: '#3B82F6' },
  visitCount: { type: Number, default: 0 },
  lastVisited: { type: Date }
}, { timestamps: true });

bookmarkSchema.index({ user: 1 });
bookmarkSchema.index({ user: 1, room: 1 }, { unique: true });


// ─── NavigationSession Schema (FR6.3 - Route History) ─────────────────────────
const navigationSessionSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  sessionId: { type: String, required: true, unique: true },

  // Route
  fromRoom: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
  toRoom: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true },
  routeType: {
    type: String,
    enum: ['fastest', 'shortest', 'wheelchair'],
    default: 'fastest'
  },

  // Computed Route
  totalDistanceMeters: { type: Number },
  estimatedTimeSeconds: { type: Number },
  actualTimeSeconds: { type: Number },
  timeSavedSeconds: { type: Number },
  steps: [{ instruction: String, distanceMeters: Number }],

  // Status
  status: {
    type: String,
    enum: ['computing', 'active', 'completed', 'cancelled', 'rerouted'],
    default: 'computing'
  },
  rerouteCount: { type: Number, default: 0 },
  completedAt: { type: Date },

  // Device Info
  deviceType: { type: String, enum: ['mobile', 'tablet', 'desktop'], default: 'mobile' }

}, { timestamps: true });

navigationSessionSchema.index({ user: 1, createdAt: -1 });
navigationSessionSchema.index({ sessionId: 1 });





module.exports = {
  Room: mongoose.model('Room', roomSchema),
  PathSegment: mongoose.model('PathSegment', pathSegmentSchema),
  Bookmark: mongoose.model('Bookmark', bookmarkSchema),
  NavigationSession: mongoose.model('NavigationSession', navigationSessionSchema)
};


