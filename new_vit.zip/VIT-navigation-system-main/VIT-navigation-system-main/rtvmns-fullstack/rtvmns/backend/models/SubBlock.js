const mongoose = require('mongoose');

const subBlockSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },

  building: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Building',
    required: true
  },

  floor: {
    type: Number,
    required: true
  },

  color: {
    type: String,
    default: '#22C55E'
  },

  // Polygon coordinates for map rendering
  polygon: [{
    lat: Number,
    lng: Number
  }],

  // Room range metadata (for display)
  roomStart: String,
  roomEnd: String

}, { timestamps: true });

subBlockSchema.index({ building: 1, floor: 1 });

module.exports = mongoose.model('SubBlock', subBlockSchema);