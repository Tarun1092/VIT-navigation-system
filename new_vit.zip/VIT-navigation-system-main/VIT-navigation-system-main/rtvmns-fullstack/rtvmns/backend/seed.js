// seed.js - Populate DB with VIT campus data
require('dotenv').config();
const mongoose = require('mongoose');
const Building = require('./models/Building');
const { Room, PathSegment } = require('./models/Room');
const User = require('./models/User');

const VIT_BUILDINGS = [
  {
    name: 'Technology Tower',
    code: 'TT',
    fullName: 'Tech Tower - Main Academic Block',
    school: 'SCOPE',
    colorScheme: { primary: '#3B82F6', secondary: '#EFF6FF', mapPin: '#2563EB' },
    location: { type: 'Point', coordinates: [79.1521, 12.9696] },
    totalFloors: 10,
    hasElevator: true,
    isAccessible: true,
    yearBuilt: 2005,
    facilities: ['wifi', 'restroom', 'atm'],
    description: 'Primary academic block for SCOPE - School of Computer Science Engineering. Houses CSE and IT departments.',
    entrances: [
      { name: 'Main Entrance', coordinates: [79.1521, 12.9694], isMainEntrance: true, isAccessible: true }
    ]
  },
  {
    name: 'Seeley G. Mudd Building',
    code: 'SMV',
    fullName: 'SMV - SELECT Building',
    school: 'SELECT',
    colorScheme: { primary: '#8B5CF6', secondary: '#F5F3FF', mapPin: '#7C3AED' },
    location: { type: 'Point', coordinates: [79.1535, 12.9700] },
    totalFloors: 8,
    hasElevator: true,
    isAccessible: true,
    facilities: ['wifi', 'restroom'],
    description: 'Houses ECE and related Electronics Engineering departments.'
  },
  {
    name: 'Grossman Building',
    code: 'GDN',
    fullName: 'GDN - Green Building',
    school: 'SMEC',
    colorScheme: { primary: '#10B981', secondary: '#ECFDF5', mapPin: '#059669' },
    location: { type: 'Point', coordinates: [79.1510, 12.9688] },
    totalFloors: 7,
    hasElevator: false,
    isAccessible: true,
    facilities: ['wifi', 'restroom', 'canteen'],
    description: 'Mechanical Engineering labs and classrooms.'
  },
  {
    name: 'Main Building',
    code: 'MB',
    fullName: 'MB - Administrative and General',
    school: 'OTHER',
    colorScheme: { primary: '#F59E0B', secondary: '#FFFBEB', mapPin: '#D97706' },
    location: { type: 'Point', coordinates: [79.1508, 12.9702] },
    totalFloors: 5,
    hasElevator: true,
    isAccessible: true,
    facilities: ['wifi', 'restroom', 'atm', 'pharmacy', 'canteen'],
    description: 'Administrative offices, registrar, and common academic facilities.'
  },
  {
    name: 'New Academic Block',
    code: 'NAB',
    fullName: 'New Academic Block - Multi-School',
    school: 'SENSE',
    colorScheme: { primary: '#EF4444', secondary: '#FEF2F2', mapPin: '#DC2626' },
    location: { type: 'Point', coordinates: [79.1545, 12.9692] },
    totalFloors: 9,
    hasElevator: true,
    isAccessible: true,
    facilities: ['wifi', 'restroom', 'canteen'],
    description: 'Multi-disciplinary academic block for Sciences and Engineering departments.'
  }
];

const ROOMS_TEMPLATE = (buildingDoc) => {
  const rooms = [];
  const types = ['classroom', 'lab', 'faculty_office', 'seminar_hall'];
  const equipment = {
    classroom: ['projector', 'AC', 'whiteboard', 'smart_board'],
    lab: ['computers', 'AC', 'projector', 'oscilloscope'],
    faculty_office: ['AC', 'computer', 'whiteboard'],
    seminar_hall: ['projector', 'AC', 'microphone', 'podium']
  };

  for (let floor = 0; floor <= 4; floor++) {
    const floorLabel = floor === 0 ? 'Ground Floor' : `${floor}${['st','nd','rd','th'][floor-1] || 'th'} Floor`;
    for (let room = 1; room <= 5; room++) {
      const type = types[room % types.length];
      const roomNum = `${buildingDoc.code}${floor}${String(room).padStart(2, '0')}`;
      rooms.push({
        roomNumber: roomNum,
        name: type === 'faculty_office'
          ? `Faculty Office - ${buildingDoc.code}${floor}${room}`
          : type === 'seminar_hall'
          ? `Seminar Hall ${floor}-${room}`
          : type === 'lab'
          ? `${buildingDoc.school} Lab ${floor}${room}`
          : `Classroom ${roomNum}`,
        type,
        building: buildingDoc._id,
        floor,
        floorLabel,
        capacity: type === 'seminar_hall' ? 120 : type === 'classroom' ? 60 : type === 'lab' ? 30 : 4,
        equipment: equipment[type] || [],
        isAccessible: true,
        isActive: true,
        isClosed: false,
        tags: [type, buildingDoc.school.toLowerCase(), buildingDoc.code.toLowerCase(), `floor${floor}`],
        position: { x: room * 120, y: floor * 80, width: 100, height: 70 },
        stats: { totalVisits: Math.floor(Math.random() * 200) }
      });
    }
  }
  return rooms;
};

async function seed() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/rtvmns');
    console.log('✅  Connected to MongoDB');

    // Clear existing data
    await Promise.all([
      Building.deleteMany({}),
      Room.deleteMany({}),
      User.deleteMany({ role: { $ne: 'admin' } })
    ]);
    console.log('🗑️   Cleared existing data');

    // Seed buildings
    const buildings = await Building.insertMany(VIT_BUILDINGS);
    console.log(`🏢  Seeded ${buildings.length} buildings`);

    // Seed rooms for each building
    const allRooms = [];
    for (const building of buildings) {
      const roomDocs = ROOMS_TEMPLATE(building);
      const rooms = await Room.insertMany(roomDocs);
      allRooms.push(...rooms);
      console.log(`   📚 ${rooms.length} rooms seeded for ${building.code}`);
    }

    // Seed path segments (connecting rooms on same floor)
    const pathSegments = [];
    for (let i = 0; i < allRooms.length - 1; i++) {
      const roomA = allRooms[i];
      const roomB = allRooms[i + 1];
      if (roomA.building.toString() === roomB.building.toString() && roomA.floor === roomB.floor) {
        pathSegments.push({
          fromNode: roomA._id,
          toNode: roomB._id,
          distanceMeters: 20 + Math.floor(Math.random() * 30),
          estimatedTimeSeconds: 15 + Math.floor(Math.random() * 20),
          pathType: 'corridor',
          isAccessible: true,
          isBidirectional: true,
          building: roomA.building
        });
      }
    }
    await PathSegment.insertMany(pathSegments);
    console.log(`🔗  Seeded ${pathSegments.length} path segments`);

    // Seed admin user
    const admin = await User.create({
      name: 'RTVMNS Admin',
      email: 'admin@vit.ac.in',
      password: 'admin123456',
      role: 'admin',
      department: 'OTHER',
      vitId: 'ADMIN001'
    });

    const student = await User.create({
      name: 'Demo Student',
      email: 'student@vit.ac.in',
      password: 'student123',
      role: 'student',
      vitId: '24MID0001',
      department: 'CSE'
    });

    console.log(`👤  Seeded admin: admin@vit.ac.in / admin123456`);
    console.log(`👤  Seeded student: student@vit.ac.in / student123`);
    console.log(`\n🎉  Database seeding complete!`);
    console.log(`   Total: ${buildings.length} buildings, ${allRooms.length} rooms, ${pathSegments.length} paths`);

    process.exit(0);
  } catch (error) {
    console.error('❌  Seeding failed:', error.message);
    process.exit(1);
  }
}

const SubBlock = require('./models/SubBlock');
const Building = require('./models/Building');

async function seedPearlSubBlocks() {
  const building = await Building.findOne({ name: "Pearl Research Park" });

  if (!building) return;

  await SubBlock.create([
    {
      name: "Ground Block A",
      building: building._id,
      floor: 0,
      color: "#F59E0B",
      roomStart: "G-10",
      roomEnd: "G-20",
      polygon: [
        { lat: 12.9711, lng: 79.1591 },
        { lat: 12.9712, lng: 79.1592 },
        { lat: 12.9713, lng: 79.1590 }
      ]
    },
    {
      name: "First Floor Wing",
      building: building._id,
      floor: 1,
      color: "#10B981",
      roomStart: "110",
      roomEnd: "141",
      polygon: [
        { lat: 12.9714, lng: 79.1593 },
        { lat: 12.9715, lng: 79.1594 },
        { lat: 12.9716, lng: 79.1592 }
      ]
    }
  ]);

  console.log("SubBlocks Created");
}

seed();
