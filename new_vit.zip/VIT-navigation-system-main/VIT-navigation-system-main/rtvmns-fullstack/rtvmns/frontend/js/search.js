// js/search.js - Search with GUI block mapping

console.log("Search initialized");

const Search = {
  selectedFrom: null,
  selectedTo: null,
  debounceTimer: null,

  // ───────────────────────────────
  // BLOCK NAME → ID MAPPING
  // ───────────────────────────────
  mapBlockNameToId(name) {

    const mapping = {
      "block a": "blockA",
      "block e": "blockE",
      "block c1": "blockC1",
      "block c2": "blockC2",
      "block f": "blockF",
      "entrance": "entrance",
      "main entrance": "mainEntrance"

    };

    return mapping[name.toLowerCase()] || null;
  },

  // ───────────────────────────────
  // ROOM → BLOCK MAPPING
  // ───────────────────────────────
  mapRoomToBlock(roomNumber) {

    if (!roomNumber) return null;

    const cleaned = roomNumber.trim().toUpperCase();
    const match = cleaned.match(/\d+/);
    if (!match) return null;

    const num = parseInt(match[0], 10);

    // BLOCK A
    if (
      (num >= 43 && num <= 54)||
      (num >= 146 && num <= 159) ||
      (num >= 241 && num <= 253) ||
      (num >= 342 && num <= 357) ||
      (num >= 437 && num <= 453) ||
      (num >= 542 && num <= 556) ||
      (num >= 642 && num <= 657) ||
      (num >= 742 && num <= 754)
    ) return "blockA";

    // BLOCK C2
    if (
      (num >= 1 && num <= 13)||
      (num >= 101 && num <= 113) ||
      (num >= 201 && num <= 212) ||
      (num >= 301 && num <= 311) ||
      (num >= 401 && num <= 410) ||
      (num >= 501 && num <= 511) ||
      (num >= 601 && num <= 609) ||
      (num >= 701 && num <= 713)
    ) return "blockC2";

    // BLOCK E
    if (
      (num >= 29 && num <= 41)||
      (num >= 132 && num <= 145) ||
      (num >= 230 && num <= 240) ||
      (num >= 327 && num <= 341) ||
      (num >= 422 && num <= 436) ||
      (num >= 527 && num <= 541) ||
      (num >= 627 && num <= 641) ||
      (num >= 729 && num <= 740)
    ) return "blockE";

    // BLOCK F
    if (
      num === 117 ||
      (num >= 216 && num <= 217) ||
      num === 315 ||
      num === 412 ||
      (num >= 513 && num <= 516) ||
      (num >= 611 && num <= 614)
    ) return "blockF";

    // BLOCK C1
    if (
      (num >= 17 && num <= 28)||
      (num >= 119 && num <= 131) ||
      (num >= 219 && num <= 229) ||
      (num >= 317 && num <= 326) ||
      (num >= 413 && num <= 421) ||
      (num >= 518 && num <= 526) ||
      (num >= 615 && num <= 626) ||
      (num >= 716 && num <= 728)
    ) return "blockC1";

    // MAIN ENTRANCE (BLUE SEGMENT)
    if (
        (num >= 115 && num <= 116) ||
        (num >= 213 && num <= 218) ||
        (num >= 312 && num <= 316) ||
        (num >= 411 && num <= 413) ||
        (num >= 512 && num <= 517) ||
        num === 610 ||
        (num >= 714 && num <= 715)
      ) return "mainEntrance";

    return null;
  },

  // ───────────────────────────────
  // INIT
  // ───────────────────────────────
  init() {

    const fromInput = document.getElementById('from-input');
    const toInput = document.getElementById('to-input');

    [fromInput, toInput].forEach(input => {

      input.addEventListener('input', (e) => {

        const value = e.target.value.trim();

        // 🔥 CLEAR previous state immediately
        if (input.id === 'from-input') {
          Search.selectedFrom = null;
        } else {
          Search.selectedTo = null;
        }

        let blockId = Search.mapBlockNameToId(value);

        if (!blockId) {
          blockId = Search.mapRoomToBlock(value);
        }

        if (!blockId) return;

        if (input.id === 'from-input') {
          Search.selectedFrom = { id: blockId };
          UI.showToast(`From: ${value}`, 'info');
        } else {
          Search.selectedTo = { id: blockId };
          UI.showToast(`To: ${value}`, 'info');
        }
        

      });

    });

    // ───────────────────────────────
    // USE MY LOCATION
    // ───────────────────────────────
    document.getElementById('use-location-btn')
      .addEventListener('click', () => {

        if (!navigator.geolocation) {
          UI.showToast('Geolocation not supported', 'error');
          return;
        }

        navigator.geolocation.getCurrentPosition(
          (pos) => {

            MapManager.setUserLocation(
              pos.coords.latitude,
              pos.coords.longitude
            );

            fromInput.value = 'My Location';

            Search.selectedFrom = {
              id: 'geolocation'
            };

            UI.showToast('📍 Location found!', 'success');
          },
          () => UI.showToast('Enable GPS to use location', 'error')
        );
      });

    // ───────────────────────────────
    // SWAP ROUTE
    // ───────────────────────────────
    document.getElementById('swap-route')
      .addEventListener('click', () => {

        const tmp = Search.selectedFrom;
        Search.selectedFrom = Search.selectedTo;
        Search.selectedTo = tmp;

        const fromVal = fromInput.value;
        fromInput.value = toInput.value;
        toInput.value = fromVal;
      });

    // ───────────────────────────────
    // ROUTE TYPE BUTTONS
    // ───────────────────────────────
    document.querySelectorAll('.route-type-btn')
      .forEach(btn => {

        btn.addEventListener('click', () => {

          document.querySelectorAll('.route-type-btn')
            .forEach(b => b.classList.remove('active'));

          btn.classList.add('active');

        });

      });

  }
};