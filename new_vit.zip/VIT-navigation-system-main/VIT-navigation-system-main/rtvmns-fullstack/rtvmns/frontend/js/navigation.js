// frontend/js/navigation.js

const Navigation = {
async getRoute(fromId, toId) {

  console.log("Sending route request:", fromId, toId);

  const response = await api.getRoute(fromId, toId);

  console.log("Route response:", response);

  if (response?.data?.route) {
    response.data.route.destBlock = toId;
    response.data.route.startBlock = fromId;
    MapManager.showRoute(response.data.route);
  } else {
    console.error("Invalid route object:", response);
  }
}

};
