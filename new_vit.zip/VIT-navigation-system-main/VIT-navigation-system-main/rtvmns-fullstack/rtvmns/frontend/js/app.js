// js/app.js - Main Application Orchestrator

const App = {

  async init() {

    UI.initTheme();
    UI.initSidebar();
    MapManager.init();
    Search.init();

    document.getElementById('voice-toggle')
      ?.addEventListener('click', Navigation.toggleVoice);

    // 🔥 GET ROUTE BUTTON
    document.getElementById('get-route-btn')
      .addEventListener('click', async () => {

        const fromInputValue = document.getElementById('from-input').value.trim();
        const toInputValue   = document.getElementById('to-input').value.trim();

        // Map destination properly
        const toBlock =
          Search.mapBlockNameToId(toInputValue) ||
          Search.mapRoomToBlock(toInputValue);

        if (!toBlock) {
          UI.showToast("Select destination", "error");
          return;
        }

        // =========================
        // GPS MODE (Proper way)
        // =========================
        if (Search.selectedFrom?.id === "geolocation") {

          navigator.geolocation.getCurrentPosition(

            async (pos) => {

              const lat = pos.coords.latitude;
              const lng = pos.coords.longitude;

              // show blue marker
              MapManager.setUserLocation(lat, lng);

              // find nearest corridor point
              // If we have a representative coordinate for the destination block,
              // draw route client-side from user -> corridor -> destination.
              const destCoord = MapManager.getBlockCoord?.(toBlock);

              if (destCoord) {
                await MapManager.showRoute({ path: [ { lat, lng }, destCoord ], destBlock: toBlock });
                return;
              }

              // Fallback: use nearest corridor node id and ask server for route
              const nearestNode = MapManager.findNearestNode(lat, lng);

              if (nearestNode === null || nearestNode === undefined) {
                UI.showToast("Cannot find nearest node", "error");
                return;
              }

              await Navigation.getRoute(
                nearestNode,
                toBlock
              );

            },

            () => {
              UI.showToast("Enable location access", "error");
            }

          );

          return;
        }

        // =========================
        // ROOM / BLOCK MODE
        // =========================
        const fromBlock =
          Search.mapBlockNameToId(fromInputValue) ||
          Search.mapRoomToBlock(fromInputValue);

        if (!fromBlock) {
          UI.showToast("Select start location", "error");
          return;
        }

        await Navigation.getRoute(
          fromBlock,
          toBlock
        );

      });

    await Auth.init();
  }
};


// Bootstrap
document.addEventListener('DOMContentLoaded', () => {
  App.init().catch(err => {
    console.error('App init failed:', err);
  });
});