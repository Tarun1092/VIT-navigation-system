const PRP_GRAPH = {
  nodes: {
    entrance: { lat: 12.97108, lng: 79.16613 },
    lobby: { lat: 12.97112, lng: 79.16630 },
    corridor1: { lat: 12.97120, lng: 79.16645 },
    blockE: { lat: 12.97140, lng: 79.16575 },
    blockC: { lat: 12.97123, lng: 79.16590 },
    blockF: { lat: 12.97088, lng: 79.16639 }
  },

  edges: {
    entrance: ["lobby"],
    lobby: ["entrance", "corridor1"],
    corridor1: ["lobby", "blockE", "blockC"],
    blockE: ["corridor1"],
    blockC: ["corridor1"],
    blockF: ["corridor1"]
  }
};