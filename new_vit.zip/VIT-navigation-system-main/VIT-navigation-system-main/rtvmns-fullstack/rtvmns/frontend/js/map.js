// js/map.js - Interactive Leaflet Map with VIT Campus + PRP Segments

// ===============================
// PRP SUBBLOCK SEGMENTS (STATIC)
// ===============================



const PRP_CORRIDOR_PATH = [
  [12.97225, 79.16668],  // top of A
  [12.97205, 79.16655],
  [12.97175, 79.16645],
  [12.97145, 79.16635],
  [12.97120, 79.16615],  // blue segment
  [12.97105, 79.16595],
  [12.97135, 79.16582],
  [12.97165, 79.16575]   // block E
];
const PRP_SEGMENTS = [
  {
    name: "PRP – Ground Floor",
    rooms: "G-10 to G-20",
    color: "#F59E0B",
    coords: [
      [12.971995058230023, 79.1655680537224],
      [12.971971534399955, 79.165758490562452],
      [12.971738909738505, 79.1655358672142],
      [12.971670951931182, 79.16585505008699]
    ]
  },
  {
    name: "PRP – First Floor Wing",
    rooms: "110 to 141",
    color: "#10B981",
    coords: [
      [12.971388665455853 ,79.16560024023057],
      [12.971156040249282,79.16565388441087],
      [12.971234453264564,79.16590332984926]
    ]
  }
];

// ===============================
// MAP MANAGER
// ===============================
const MapManager = {


showRoute(route) {

  if (this.routeLayer) {
    this.map.removeLayer(this.routeLayer);
  }

  if (!route || !route.path || route.path.length === 0) {
    console.error("Invalid route object:", route);
    return;
  }

  const start = route.path[0];
  const end   = route.path[route.path.length - 1];

  const nearestIndex = (point) => {
    let min = Infinity;
    let index = 0;

    PRP_CORRIDOR_PATH.forEach((c, i) => {
      const d = Math.sqrt(
        (point.lat - c[0]) ** 2 +
        (point.lng - c[1]) ** 2
      );
      if (d < min) {
        min = d;
        index = i;
      }
    });

    return index;
  };

  const startIndex = nearestIndex(start);
  const endIndex   = nearestIndex(end);

  let sliced;

  if (startIndex <= endIndex) {
    sliced = PRP_CORRIDOR_PATH.slice(startIndex, endIndex + 1);
  } else {
    sliced = PRP_CORRIDOR_PATH
      .slice(endIndex, startIndex + 1)
      .reverse();
  }

  let fullPath = [];

  // ---------- START SEGMENT ENTRY ----------
  if (route.startBlock && MapManager.prpPolygonMap[route.startBlock]) {

    const meta = MapManager.prpPolygonMap[route.startBlock];
    const center = meta.centroid;

    const corridorEntry = sliced[0];

    const entryPoint =
      MapManager._rayPolygonIntersection(
        center,
        { lat: corridorEntry[0], lng: corridorEntry[1] },
        meta.coords
      ) ||
      MapManager._nearestPointOnPolygonBoundary(
        { lat: corridorEntry[0], lng: corridorEntry[1] },
        meta.coords
      );

    fullPath.push([center.lat, center.lng]);
    fullPath.push([entryPoint.lat, entryPoint.lng]);

  } else {
    fullPath.push([start.lat, start.lng]);
  }

  // ---------- CORRIDOR ----------
  sliced.forEach(p => {
    fullPath.push([p[0], p[1]]);
  });

  // ---------- DESTINATION SEGMENT ENTRY ----------
  console.log("DEBUG: route.destBlock =", route.destBlock);
  console.log("DEBUG: prpPolygonMap keys =", Object.keys(MapManager.prpPolygonMap));
  console.log("DEBUG: end =", end);
  
  if (route.destBlock && MapManager.prpPolygonMap[route.destBlock]) {

    const meta = MapManager.prpPolygonMap[route.destBlock];
    const center = meta.centroid;

    const corridorExit = sliced[sliced.length - 1];

    console.log("DEBUG: Using destBlock logic. center =", center, "corridorExit =", corridorExit);

    const entryPoint =
      MapManager._rayPolygonIntersection(
        { lat: corridorExit[0], lng: corridorExit[1] },
        center,
        meta.coords
      ) ||
      MapManager._nearestPointOnPolygonBoundary(
        { lat: corridorExit[0], lng: corridorExit[1] },
        meta.coords
      );

    console.log("DEBUG: entryPoint =", entryPoint);

    fullPath.push([entryPoint.lat, entryPoint.lng]);
    fullPath.push([center.lat, center.lng]);

  } else {
    console.log("DEBUG: Using end location logic");
    fullPath.push([end.lat, end.lng]);
  }

  // ---------- DRAW ----------
  this.routeLayer = L.polyline(fullPath, {
    color: "blue",
    weight: 14,
    opacity: 0.95,
    lineJoin: "round",
    lineCap: "round"
  }).addTo(this.map);

  this.map.fitBounds(this.routeLayer.getBounds(), {
    maxZoom: 18
  });
},

findNearestNode(lat, lng) {

  let min = Infinity;
  let nearestIndex = 0;

  PRP_CORRIDOR_PATH.forEach((coord, i) => {

    const d = Math.sqrt(
      (lat - coord[0]) ** 2 +
      (lng - coord[1]) ** 2
    );

    if (d < min) {
      min = d;
      nearestIndex = i;
    }

  });

  return nearestIndex;
},

  // Return a representative coordinate for a named PRP block id
  getBlockCoord(blockId) {
    if (!blockId) return null;
    // prefer polygon centroid if available
    const p = MapManager.prpPolygonMap[blockId];
    if (p && p.centroid) return { lat: p.centroid.lat, lng: p.centroid.lng };

    const mapping = {
      blockE: { lat: 12.972049947158158, lng: 79.16562438011171 },
      blockC1: { lat: 12.971393892986088, lng: 79.16559219360353 },
      mainEntrance: { lat: 12.97107762720928,  lng: 79.16613131761552 },
      entrance: { lat: 12.97107762720928,  lng: 79.16613131761552 },
      blockC2: { lat: 12.971634359258008, lng: 79.16662752628328 },
      blockA: { lat: 12.97234530165881,  lng: 79.16662216186525 },
      blockF: { lat: 12.970886822042027, lng: 79.16639417409898 }
    };

    return mapping[blockId] || null;
  },

  map: null,
  buildingMarkers: [],
  userMarker: null,
  routeLayer: null,
  currentBuilding: null,
  prpLayerGroup: null,
  prpPolygonMap: {},

  VIT_CENTER: [12.96985, 79.15335],
  VIT_ZOOM: 19,

  init() {

    // Initialize map
    MapManager.map = L.map('map', {
      center: MapManager.VIT_CENTER,
      zoom: MapManager.VIT_ZOOM,
      zoomControl: false,
      attributionControl: true
    });

    MapManager.setTileLayer('standard');

    L.control.zoom({ position: 'bottomright' }).addTo(MapManager.map);

    MapManager.map.on('click', function(e) {
      console.log("Lat:", e.latlng.lat, "Lng:", e.latlng.lng);
    });

    document.getElementById('recenter-btn').addEventListener('click', () => {
      MapManager.recenter();
    });

    document.getElementById('fullscreen-btn').addEventListener('click', () => {
      MapManager.toggleFullscreen();
    });

    // Initialize PRP Layer
    MapManager.prpLayerGroup = L.layerGroup();
    MapManager.setupPRPSegments();
  },

  // ===============================
  // TILE LAYER
  // ===============================
  setTileLayer(type = 'standard') {

    if (MapManager._tileLayer)
      MapManager.map.removeLayer(MapManager._tileLayer);

    const tiles = {
      standard: {
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        attribution: '© OpenStreetMap'
      },
      satellite: {
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attribution: '© Esri'
      }
    };

    const t = tiles[type] || tiles.standard;

    MapManager._tileLayer = L.tileLayer(t.url, {
      attribution: t.attribution,
      maxZoom: 21
    }).addTo(MapManager.map);
  },

  // ===============================
  // PRP SEGMENTS LOGIC
  // ===============================
  setupPRPSegments() {
    MapManager.prpLayerGroup = L.layerGroup().addTo(MapManager.map);
    MapManager.map.setView([12.96985, 79.15335], 19);
    MapManager.renderPRPSegments(); // Start with Ground floor
  },

  renderPRPSegments(floor = 0) {

  MapManager.prpLayerGroup.clearLayers();

  // clear polygon map for fresh render
  MapManager.prpPolygonMap = {};

  

  const FLOOR_SEGMENTS = {
    0: [ // Ground Floor
      {
        id: 'blockE',
        name: "PRP BLock E",
        rooms: "<br>G-29 to G-41<br>132-145<br>230-240<br>327-341<br>422-436<br>527-541<br>627-641<br>729-740",
        color: "#F59E0B",
        coords: [
          [12.972049947158158,79.16562438011171],
          [12.9719192592141,79.16552245616914],
          [12.971422644400384,79.16558951139451],
          [12.971433099459317,79.16588723659517],
          [12.97180164000572,79.16591405868532],
          [12.972002899506203,79.16573971509935]
          
          
        ]
      }
    ],

    1: [ // First Floor
      {
        id: 'blockC1',
        name: "PRP Block C1",
        rooms: "<br>G17-G28<br>119-131<br>219-229<br>317-326<br>413-421<br>518-526<br>615-626<br>716-728",
        color: "#10B981",
        coords: [
        [12.971393892986088, 79.16559219360353],  // top-left
        [12.971299797425086, 79.16561365127565],  // upper-left
        [12.971166495319421, 79.16563242673875],  // left
        [12.971090696051,    79.16577458381653],  // lower-left
        [12.970949552524122, 79.16578799486162],  // bottom-left
        [12.97089204958281,  79.16592746973039],  // bottom
        [12.970944324984561, 79.16598647832872],  // bottom-right
        [12.971048875755088, 79.16606426239015],  // right-lower
        [12.97117433662172,  79.16604280471803],  // right
        [12.971223998197287, 79.16592478752138],  // upper-right
        [12.971386051690684, 79.1658891880417]    // close to start
             
        ]
      }
    ],

    2: [ // Second Floor
      {
        id: 'mainEntrance',
        name: "PRP Main Entrance",
        rooms: "<br>G14-16<br>115-116<br>213-218<br>312-316<br>411-413<br>512-517<br>610<br>714-715",
        color: "#3B82F6",
        coords: [
          [12.97107762720928, 79.16613131761552],  // top
          [12.970933869905084, 79.16602134704591], // upper-left
          [12.970868525648433, 79.16605621576309], // left
          [12.970871139419021, 79.16621178388596], // lower-left
          [12.97092341482516,  79.166399538517],   // bottom-left
          [12.971048875755088, 79.16632980108263], // bottom-right
          [12.971072399672403, 79.1662520170212]   // upper-right

          
        ]
      }
    ],

    3: [ // Second Floor
      {
        id: 'blockF',
        name: "PRP Block F",
        rooms: "<br>117<br>216-217<br>315<br>412<br>513-516<br>611-614",
        color: "#3babf6",
        coords: [
        [12.970886822042027, 79.16639417409898],  // top
        [12.97073260953963,  79.16645586490633],  // upper-right
        [12.97062021731663,  79.16627883911134],  // bottom-right
        [12.970688175411018, 79.16608572006227],  // bottom-left
        [12.97083454662819,  79.16605889797212]   // upper-left

          
        ]
      }
    ],
    4: [ // Second Floor
      {
        id: 'blockC2',
        name: "PRP Block C2",
        rooms: "<br>G01-G13<br>101-113<br>201-212<br>301-311<br>401-410<br>501-511<br>601-609<br>701-713",
        color: "#b8ee61",
        coords: [
          [12.971634359258008, 79.16662752628328],
          [12.971545491315023, 79.16651219129564],
          [12.971430485694619, 79.16653364896776],
          [12.97140696181118,  79.16649341583252],
          [12.971325935084481, 79.16649609804155],
          [12.97131025248917,  79.16653364896776],
          [12.971271045996566, 79.16654437780382],
          [12.971297183658988,79.16641294956209],
          [12.971213543129577, 79.1663083434105],
          [12.97108546851439,  79.16631639003754],
          [12.970999214144571, 79.16643172502519],
          [12.970970462681308, 79.16648268699646],
          [12.971048875755088, 79.1665953397751],
          [12.971218770663489, 79.16657119893937],
          [12.971312866255127, 79.16669726371767],
          [12.971448782046892, 79.16669726371767],
          [12.971548105078513, 79.1666239500047]

        ]
      }
    ],
    5: [ // Second Floor
      {
        id: 'blockA',
        name: "PRP Block A",
        rooms: "<br>G43-G54<br>146-159<br>241-253<br>342-357<br>437-453<br>542-556<br>642-657<br>742-754",
        color: "#d26912",
        coords: [
          [12.97234530165881, 79.16662216186525],  // top
          [12.972337460393419, 79.16662216186525], 
          [12.97226166148183, 79.16649341583252],
          [12.972104836074209, 79.16650682687761],
          [12.971997671988767, 79.166396856308],
          [12.971848687695742, 79.16644513607027],
          [12.971783343679425, 79.16662484407426],
          [12.971548105078513, 79.1666677594185],
          [12.971571628948618, 79.16685283184053],
          [12.971595152816484, 79.1669011116028],
          [12.97227473026135, 79.1667938232422]

        ]
      }
    ]
    
  };

  const segments = Object.values(FLOOR_SEGMENTS).flat();

    segments.forEach(segment => {

    const polygon = L.polygon(segment.coords, {
      color: segment.color,
      fillColor: segment.color,
      fillOpacity: 0.85,
      weight: 4
    });

    polygon.on('mouseover', function () {
      this.setStyle({ fillOpacity: 0.85 });
    });

    polygon.on('mouseout', function () {
      this.setStyle({ fillOpacity: 0.6 });
    });

      polygon.on('click', function () {
        L.popup()
          .setLatLng(segment.coords[0])
          .setContent(`
            <div>
              <h3>${segment.name}</h3>
              <p>Rooms: <strong>${segment.rooms}</strong></p>
            </div>
        `)
        .openOn(MapManager.map);
      });
      MapManager.prpLayerGroup.addLayer(polygon);
      // store polygon and centroid by id when provided
      if (segment.id) {
        const centroid = MapManager._computeCentroid(segment.coords);
        MapManager.prpPolygonMap[segment.id] = {
          polygon,
          coords: segment.coords,
          centroid
        };
      }
      MapManager.map.fitBounds(polygon.getBounds());
    });
  },

  _computeCentroid(coords) {
    let lat = 0, lng = 0;
    coords.forEach(c => { lat += c[0]; lng += c[1]; });
    return { lat: lat / coords.length, lng: lng / coords.length };
  },

  // Find intersection of ray from point A through point B with polygon boundary
  _rayPolygonIntersection(rayStart, rayEnd, polygonCoords) {
    let closestIntersection = null;
    let closestDist = Infinity;
    
    const rayDir = {
      lat: rayEnd.lat - rayStart.lat,
      lng: rayEnd.lng - rayStart.lng
    };
    const rayLen = Math.sqrt(rayDir.lat**2 + rayDir.lng**2);
    if (rayLen === 0) return null;
    
    // Check each edge of polygon
    for (let i = 0; i < polygonCoords.length; i++) {
      const A = polygonCoords[i];
      const B = polygonCoords[(i + 1) % polygonCoords.length];
      
      const edgeDir = { lat: B[0] - A[0], lng: B[1] - A[1] };
      const toRayStart = { lat: rayStart.lat - A[0], lng: rayStart.lng - A[1] };
      
      const denom = edgeDir.lat * rayDir.lng - edgeDir.lng * rayDir.lat;
      if (Math.abs(denom) < 1e-10) continue;
      
      const t = (toRayStart.lat * rayDir.lng - toRayStart.lng * rayDir.lat) / denom;
      const s = (toRayStart.lat * edgeDir.lng - toRayStart.lng * edgeDir.lat) / denom;
      
      if (t >= 0 && t <= 1 && s > 0.0001) {
        const intersection = {
          lat: A[0] + t * edgeDir.lat,
          lng: A[1] + t * edgeDir.lng
        };
        const dist = Math.sqrt(s**2 * (rayDir.lat**2 + rayDir.lng**2));
        if (dist < closestDist) {
          closestDist = dist;
          closestIntersection = intersection;
        }
      }
    }
    return closestIntersection;
  },

  // Find nearest point on a segment AB to point P (all {lat,lng})
  _nearestPointOnSegment(P, A, B) {
    const vx = B[0] - A[0];
    const vy = B[1] - A[1];
    const wx = P.lat - A[0];
    const wy = P.lng - A[1];
    const c1 = vx * wx + vy * wy;
    const c2 = vx * vx + vy * vy;
    let t = c2 === 0 ? 0 : c1 / c2;
    t = Math.max(0, Math.min(1, t));
    return { lat: A[0] + vx * t, lng: A[1] + vy * t };
  },

  // Find closest point on polygon boundary to point P
  _nearestPointOnPolygonBoundary(P, polygonCoords) {
    let best = null;
    let bestDist = Infinity;
    for (let i = 0; i < polygonCoords.length; i++) {
      const A = polygonCoords[i];
      const B = polygonCoords[(i + 1) % polygonCoords.length];
      const candidate = MapManager._nearestPointOnSegment(P, A, B);
      const d = Math.sqrt((P.lat - candidate.lat) ** 2 + (P.lng - candidate.lng) ** 2);
      if (d < bestDist) {
        bestDist = d;
        best = candidate;
      }
    }
    return best;
  },

  // ray-casting algorithm to test if a point lies inside a polygon
  _pointInPolygon(point, polygonCoords) {
    let inside = false;
    for (let i = 0, j = polygonCoords.length - 1; i < polygonCoords.length; j = i++) {
      const xi = polygonCoords[i][0], yi = polygonCoords[i][1];
      const xj = polygonCoords[j][0], yj = polygonCoords[j][1];
      const intersect = ((yi > point.lng) !== (yj > point.lng)) &&
        (point.lat < (xj - xi) * (point.lng - yi) / (yj - yi) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  },

  // choose a point guaranteed inside the polygon
  _interiorPoint(polygonCoords) {
    // first try centroid
    const centroid = MapManager._computeCentroid(polygonCoords);
    if (MapManager._pointInPolygon(centroid, polygonCoords)) {
      return centroid;
    }
    // try midpoints of edges
    for (let i = 0; i < polygonCoords.length; i++) {
      const A = polygonCoords[i];
      const B = polygonCoords[(i + 1) % polygonCoords.length];
      const mid = { lat: (A[0] + B[0]) / 2, lng: (A[1] + B[1]) / 2 };
      if (MapManager._pointInPolygon(mid, polygonCoords)) {
        return mid;
      }
    }
    // last resort: just jitter centroid slightly inward
    return centroid;
  },

  // ===============================
  // USER LOCATION
  // ===============================
  setUserLocation(lat, lng) {

    if (MapManager.userMarker)
      MapManager.map.removeLayer(MapManager.userMarker);

    const icon = L.divIcon({
      html: '<div class="user-location-marker"></div>',
      className: '',
      iconSize: [18, 18],
      iconAnchor: [9, 9]
    });

    MapManager.userMarker = L.marker([lat, lng], { icon })
      .bindPopup('<b>📍 You are here</b>')
      .addTo(MapManager.map);
  },

  recenter() {
    if (MapManager.userMarker) {
      MapManager.map.setView(
        MapManager.userMarker.getLatLng(),
        18,
        { animate: true }
      );
    } else {
      MapManager.map.setView(
        MapManager.VIT_CENTER,
        MapManager.VIT_ZOOM,
        { animate: true }
      );
    }
  },

  // ===============================
  // ROUTE
  // ===============================
  clearRoute() {
    if (MapManager.routeLayer) {
      MapManager.map.removeLayer(MapManager.routeLayer);
      MapManager.routeLayer = null;
    }
  },
  clearUserLocation() {
  if (this.userMarker) {
    this.userMarker.remove();
    this.userMarker = null;
    }
  },

  // ===============================
  // FULLSCREEN
  // ===============================
  toggleFullscreen() {
    const el = document.getElementById('map-container');

    if (!document.fullscreenElement) {
      el.requestFullscreen?.();
      document.getElementById('fullscreen-btn')
        .querySelector('ion-icon').name = 'contract-outline';
    } else {
      document.exitFullscreen?.();
      document.getElementById('fullscreen-btn')
        .querySelector('ion-icon').name = 'expand-outline';
    }
  }

};

