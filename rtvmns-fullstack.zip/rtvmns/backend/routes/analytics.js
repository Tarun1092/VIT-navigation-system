// routes/analytics.js  (FR7.3 - Usage Analytics Dashboard)
const express = require('express');
const router = express.Router();
const { NavigationSession, Room } = require('../models/Room');
const Building = require('../models/Building');
const { protect, restrictTo } = require('../middleware/auth');

// GET /api/analytics/overview  - Admin dashboard overview
router.get('/overview', protect, restrictTo('admin'), async (req, res) => {
  try {
    const User = require('../models/User');

    const [
      totalUsers, totalBuildings, totalRooms,
      totalSessions, completedSessions, avgSessionData
    ] = await Promise.all([
      User.countDocuments({ isActive: true }),
      Building.countDocuments({ isActive: true }),
      Room.countDocuments({ isActive: true }),
      NavigationSession.countDocuments(),
      NavigationSession.countDocuments({ status: 'completed' }),
      NavigationSession.aggregate([
        { $match: { status: 'completed' } },
        {
          $group: {
            _id: null,
            avgDistance: { $avg: '$totalDistanceMeters' },
            avgTime: { $avg: '$estimatedTimeSeconds' },
            totalTimeSaved: { $sum: '$timeSavedSeconds' }
          }
        }
      ])
    ]);

    res.json({
      success: true,
      data: {
        users: { total: totalUsers },
        buildings: { total: totalBuildings },
        rooms: { total: totalRooms },
        navigation: {
          totalSessions,
          completedSessions,
          completionRate: totalSessions ? Math.round((completedSessions / totalSessions) * 100) : 0,
          avgDistanceMeters: Math.round(avgSessionData[0]?.avgDistance || 0),
          avgTimeSeconds: Math.round(avgSessionData[0]?.avgTime || 0),
          totalTimeSavedMinutes: Math.round((avgSessionData[0]?.totalTimeSaved || 0) / 60)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/analytics/peak-traffic  - Peak traffic zones (FR7.3)
router.get('/peak-traffic', protect, restrictTo('admin'), async (req, res) => {
  try {
    const peakZones = await NavigationSession.aggregate([
      { $match: { status: 'completed', toRoom: { $exists: true } } },
      { $group: { _id: '$toRoom', visitCount: { $sum: 1 } } },
      { $sort: { visitCount: -1 } },
      { $limit: 10 },
      {
        $lookup: {
          from: 'rooms',
          localField: '_id',
          foreignField: '_id',
          as: 'room'
        }
      },
      { $unwind: '$room' }
    ]);

    const popularRoutes = await NavigationSession.aggregate([
      { $match: { status: 'completed', fromRoom: { $exists: true } } },
      {
        $group: {
          _id: { from: '$fromRoom', to: '$toRoom' },
          count: { $sum: 1 }
        }
      },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);

    const hourlyTraffic = await NavigationSession.aggregate([
      { $match: { createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } } },
      {
        $group: {
          _id: { hour: { $hour: '$createdAt' } },
          count: { $sum: 1 }
        }
      },
      { $sort: { '_id.hour': 1 } }
    ]);

    res.json({
      success: true,
      data: { peakZones, popularRoutes, hourlyTraffic }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/analytics/suggestions  - Smart destination suggestions (FR6.2)
router.get('/suggestions', protect, async (req, res) => {
  try {
    const User = require('../models/User');
    const user = await User.findById(req.user._id)
      .populate({
        path: 'frequentDestinations.roomId',
        select: 'roomNumber name type building floor',
        populate: { path: 'building', select: 'name code colorScheme' }
      })
      .lean();

    const suggestions = (user.frequentDestinations || [])
      .sort((a, b) => b.visitCount - a.visitCount)
      .slice(0, 5)
      .filter(d => d.roomId);

    const hour = new Date().getHours();
    const timeLabel = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';

    res.json({
      success: true,
      data: {
        suggestions,
        contextHint: `Good ${timeLabel}! Based on your history:`,
        suggestionsCount: suggestions.length
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
