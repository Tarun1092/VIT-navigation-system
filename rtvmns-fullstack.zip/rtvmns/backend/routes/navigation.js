// routes/navigation.js
const express = require('express');
const router = express.Router();
const { protect, optionalAuth } = require('../middleware/auth');
const { getRoute, getNearbyPOIs } = require('../controllers/navigationController');
const { NavigationSession } = require('../models/Room');
const { v4: uuidv4 } = require('crypto');

// GET /api/navigation/route?from=ID&to=ID&type=fastest  (FR3)
router.get('/route', optionalAuth, getRoute);

// GET /api/navigation/nearby?roomId=ID&types=canteen,washroom  (FR5)
router.get('/nearby', getNearbyPOIs);

// POST /api/navigation/session  - Start a nav session for tracking
router.post('/session', protect, async (req, res) => {
  try {
    const { fromRoom, toRoom, routeType, estimatedTime, distance } = req.body;

    const session = await NavigationSession.create({
      user: req.user._id,
      sessionId: `nav_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      fromRoom,
      toRoom,
      routeType: routeType || 'fastest',
      estimatedTimeSeconds: estimatedTime,
      totalDistanceMeters: distance,
      status: 'active'
    });

    res.status(201).json({ success: true, data: { sessionId: session.sessionId, id: session._id } });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// PATCH /api/navigation/session/:sessionId  - Complete or cancel session
router.patch('/session/:sessionId', protect, async (req, res) => {
  try {
    const { status, actualTime } = req.body;
    const session = await NavigationSession.findOneAndUpdate(
      { sessionId: req.params.sessionId, user: req.user._id },
      {
        status,
        actualTimeSeconds: actualTime,
        timeSavedSeconds: session?.estimatedTimeSeconds
          ? Math.max(0, (session.estimatedTimeSeconds - actualTime)) : 0,
        completedAt: status === 'completed' ? new Date() : undefined
      },
      { new: true }
    );

    if (!session) return res.status(404).json({ success: false, error: 'Session not found' });
    res.json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/navigation/history  - User navigation history (FR6.3)
router.get('/history', protect, async (req, res) => {
  try {
    const sessions = await NavigationSession.find({ user: req.user._id, status: 'completed' })
      .populate('fromRoom', 'roomNumber name building')
      .populate('toRoom', 'roomNumber name building')
      .sort('-createdAt')
      .limit(20)
      .lean();

    const totalTimeSaved = sessions.reduce((sum, s) => sum + (s.timeSavedSeconds || 0), 0);
    const totalDistance = sessions.reduce((sum, s) => sum + (s.totalDistanceMeters || 0), 0);

    res.json({
      success: true,
      data: {
        sessions,
        stats: {
          totalTrips: sessions.length,
          totalTimeSavedMinutes: Math.round(totalTimeSaved / 60),
          totalDistanceKm: (totalDistance / 1000).toFixed(2)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
