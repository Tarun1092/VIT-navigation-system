// routes/admin.js  (FR7 - Admin Functions)
const express = require('express');
const router = express.Router();
const Building = require('../models/Building');
const { Room, PathSegment, NavigationSession } = require('../models/Room');
const { protect, restrictTo } = require('../middleware/auth');

// All admin routes require auth + admin role
router.use(protect, restrictTo('admin'));

// ─── Buildings CRUD ────────────────────────────────────────────────────────────

// POST /api/admin/buildings
router.post('/buildings', async (req, res) => {
  try {
    const building = await Building.create(req.body);
    res.status(201).json({ success: true, data: building });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// PUT /api/admin/buildings/:id  (FR7.1 - Edit POIs)
router.put('/buildings/:id', async (req, res) => {
  try {
    const building = await Building.findByIdAndUpdate(req.params.id, req.body, {
      new: true, runValidators: true
    });
    if (!building) return res.status(404).json({ success: false, error: 'Building not found' });
    res.json({ success: true, data: building });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// PATCH /api/admin/buildings/:id/closure  (FR7.2 - Temporary closures)
router.patch('/buildings/:id/closure', async (req, res) => {
  try {
    const { isUnderConstruction, constructionNote } = req.body;
    const building = await Building.findByIdAndUpdate(
      req.params.id,
      { isUnderConstruction, constructionNote },
      { new: true }
    );
    res.json({ success: true, data: building });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ─── Rooms CRUD ────────────────────────────────────────────────────────────────

// POST /api/admin/rooms
router.post('/rooms', async (req, res) => {
  try {
    const room = await Room.create(req.body);
    res.status(201).json({ success: true, data: room });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// PUT /api/admin/rooms/:id
router.put('/rooms/:id', async (req, res) => {
  try {
    const room = await Room.findByIdAndUpdate(req.params.id, req.body, {
      new: true, runValidators: true
    });
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });
    res.json({ success: true, data: room });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// PATCH /api/admin/rooms/:id/closure  (FR7.2 - Room closures for events, construction)
router.patch('/rooms/:id/closure', async (req, res) => {
  try {
    const { isClosed, closureNote } = req.body;
    const room = await Room.findByIdAndUpdate(
      req.params.id,
      { isClosed, closureNote },
      { new: true }
    );
    res.json({ success: true, data: room });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ─── Path Segments (Graph Edges) ──────────────────────────────────────────────

// POST /api/admin/paths
router.post('/paths', async (req, res) => {
  try {
    const segment = await PathSegment.create(req.body);
    res.status(201).json({ success: true, data: segment });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// PATCH /api/admin/paths/:id/block  (FR3.3 - Block paths for construction)
router.patch('/paths/:id/block', async (req, res) => {
  try {
    const { isBlocked, blockageReason, blockageUntil } = req.body;
    const segment = await PathSegment.findByIdAndUpdate(
      req.params.id,
      { isBlocked, blockageReason, blockageUntil },
      { new: true }
    );
    if (!segment) return res.status(404).json({ success: false, error: 'Path segment not found' });
    res.json({ success: true, data: segment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/admin/users  - List all users
router.get('/users', async (req, res) => {
  try {
    const User = require('../models/User');
    const users = await User.find().select('-password').sort('-createdAt').lean();
    res.json({ success: true, count: users.length, data: users });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
