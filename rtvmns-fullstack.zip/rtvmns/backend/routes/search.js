// routes/search.js  (FR2 - Location Search with fuzzy matching)
const express = require('express');
const router = express.Router();
const { Room } = require('../models/Room');
const Building = require('../models/Building');

// GET /api/search?q=CSE204
router.get('/', async (req, res) => {
  try {
    const { q, type, building, limit = 10 } = req.query;
    if (!q || q.trim().length < 2) {
      return res.status(400).json({ success: false, error: 'Query must be at least 2 characters' });
    }

    const searchTerm = q.trim();
    const queryLimit = Math.min(parseInt(limit), 50);

    // Multi-field search: room number, name, tags, aliases, course codes
    const roomQuery = {
      isActive: true,
      $or: [
        { roomNumber: { $regex: searchTerm, $options: 'i' } },
        { name: { $regex: searchTerm, $options: 'i' } },
        { tags: { $in: [new RegExp(searchTerm, 'i')] } },
        { aliases: { $in: [new RegExp(searchTerm, 'i')] } },
        { 'schedule.courseCode': { $regex: searchTerm, $options: 'i' } },
        { 'schedule.courseName': { $regex: searchTerm, $options: 'i' } }
      ]
    };

    if (type) roomQuery.type = { $in: type.split(',') };
    if (building) roomQuery.building = building;

    // Search rooms and buildings in parallel
    const [rooms, buildings] = await Promise.all([
      Room.find(roomQuery)
        .populate('building', 'name code colorScheme imageUrl')
        .select('roomNumber name type floor capacity isOccupied currentCourse isAccessible building')
        .limit(queryLimit)
        .lean(),
      Building.find({
        isActive: true,
        $or: [
          { name: { $regex: searchTerm, $options: 'i' } },
          { code: { $regex: searchTerm, $options: 'i' } },
          { fullName: { $regex: searchTerm, $options: 'i' } }
        ]
      }).select('name code fullName school colorScheme imageUrl location')
        .limit(5).lean()
    ]);

    // Merge and rank results
    const results = [
      ...buildings.map(b => ({ ...b, resultType: 'building', score: 100 })),
      ...rooms.map(r => ({
        ...r,
        resultType: 'room',
        score: r.roomNumber?.toLowerCase().startsWith(searchTerm.toLowerCase()) ? 90 : 70
      }))
    ].sort((a, b) => b.score - a.score);

    res.json({
      success: true,
      query: searchTerm,
      count: results.length,
      data: results
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/search/autocomplete?q=CS  (FR2.3)
router.get('/autocomplete', async (req, res) => {
  try {
    const { q, limit = 8 } = req.query;
    if (!q || q.length < 1) return res.json({ success: true, data: [] });

    const suggestions = await Room.find({
      isActive: true,
      $or: [
        { roomNumber: { $regex: `^${q}`, $options: 'i' } },
        { name: { $regex: q, $options: 'i' } }
      ]
    })
    .select('roomNumber name type building floor')
    .populate('building', 'code')
    .limit(parseInt(limit))
    .lean();

    const autocomplete = suggestions.map(r => ({
      id: r._id,
      label: r.name ? `${r.roomNumber} – ${r.name}` : r.roomNumber,
      type: r.type,
      building: r.building?.code || '',
      floor: r.floor
    }));

    res.json({ success: true, data: autocomplete });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
