// routes/bookmarks.js  (FR6.1 - Up to 20 bookmarks)
const express = require('express');
const router = express.Router();
const { Bookmark } = require('../models/Room');
const User = require('../models/User');
const { protect } = require('../middleware/auth');

// GET /api/bookmarks
router.get('/', protect, async (req, res) => {
  try {
    const bookmarks = await Bookmark.find({ user: req.user._id })
      .populate({
        path: 'room',
        select: 'roomNumber name type floor building capacity isOccupied',
        populate: { path: 'building', select: 'name code colorScheme' }
      })
      .sort('-createdAt')
      .lean();

    res.json({ success: true, count: bookmarks.length, data: bookmarks });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/bookmarks
router.post('/', protect, async (req, res) => {
  try {
    const { roomId, customName, icon, color } = req.body;
    if (!roomId) return res.status(400).json({ success: false, error: 'roomId is required' });

    // Enforce 20 bookmark limit (FR6.1)
    const count = await Bookmark.countDocuments({ user: req.user._id });
    if (count >= 20) {
      return res.status(400).json({
        success: false,
        error: 'Bookmark limit reached (20 maximum). Remove a bookmark to add a new one.'
      });
    }

    const existing = await Bookmark.findOne({ user: req.user._id, room: roomId });
    if (existing) {
      return res.status(409).json({ success: false, error: 'Already bookmarked' });
    }

    const bookmark = await Bookmark.create({
      user: req.user._id,
      room: roomId,
      customName,
      icon: icon || '📍',
      color: color || '#3B82F6'
    });

    // Add to user's bookmarks array
    await User.findByIdAndUpdate(req.user._id, { $push: { bookmarks: bookmark._id } });

    const populated = await bookmark.populate({
      path: 'room',
      select: 'roomNumber name type floor building',
      populate: { path: 'building', select: 'name code' }
    });

    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// PATCH /api/bookmarks/:id  - Rename bookmark
router.patch('/:id', protect, async (req, res) => {
  try {
    const { customName, icon, color } = req.body;
    const bookmark = await Bookmark.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { customName, icon, color },
      { new: true, runValidators: true }
    ).populate('room', 'roomNumber name building');

    if (!bookmark) return res.status(404).json({ success: false, error: 'Bookmark not found' });
    res.json({ success: true, data: bookmark });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// DELETE /api/bookmarks/:id
router.delete('/:id', protect, async (req, res) => {
  try {
    const bookmark = await Bookmark.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!bookmark) return res.status(404).json({ success: false, error: 'Bookmark not found' });

    await User.findByIdAndUpdate(req.user._id, { $pull: { bookmarks: bookmark._id } });

    res.json({ success: true, message: 'Bookmark removed' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
