// routes/buildings.js
const express = require('express');
const router = express.Router();
const Building = require('../models/Building');
const { Room } = require('../models/Room');
const { protect, restrictTo } = require('../middleware/auth');

// GET /api/buildings  - List all active buildings
router.get('/', async (req, res) => {
  try {
    const { school, search } = req.query;
    const query = { isActive: true };
    if (school) query.school = school;
    if (search) query.$text = { $search: search };

    const buildings = await Building.find(query)
      .select('-floorPlans.svgData')
      .sort('name')
      .lean();

    res.json({ success: true, count: buildings.length, data: buildings });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/buildings/:id  - Single building with floors
router.get('/:id', async (req, res) => {
  try {
    const building = await Building.findById(req.params.id).lean();
    if (!building) return res.status(404).json({ success: false, error: 'Building not found' });

    const rooms = await Room.find({ building: building._id, isActive: true })
      .select('roomNumber name type floor capacity isOccupied currentCourse equipment isAccessible')
      .sort('floor roomNumber')
      .lean();

    const floorMap = {};
    rooms.forEach(room => {
      const f = room.floor;
      if (!floorMap[f]) floorMap[f] = [];
      floorMap[f].push(room);
    });

    res.json({ success: true, data: { ...building, roomsByFloor: floorMap } });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/buildings/:id/floorplan/:floor  - Floor plan SVG
router.get('/:id/floorplan/:floor', async (req, res) => {
  try {
    const building = await Building.findById(req.params.id)
      .select('floorPlans name code').lean();
    if (!building) return res.status(404).json({ success: false, error: 'Building not found' });

    const floorPlan = building.floorPlans?.find(fp => fp.floorNumber === parseInt(req.params.floor));
    if (!floorPlan) return res.status(404).json({ success: false, error: 'Floor plan not available' });

    res.json({ success: true, data: floorPlan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
