// routes/rooms.js
const express = require('express');
const router = express.Router();
const { Room } = require('../models/Room');
const { protect } = require('../middleware/auth');

// GET /api/rooms  - List rooms with filters
router.get('/', async (req, res) => {
  try {
    const { building, floor, type, accessible } = req.query;
    const query = { isActive: true };

    if (building) query.building = building;
    if (floor !== undefined) query.floor = parseInt(floor);
    if (type) query.type = { $in: type.split(',') };
    if (accessible === 'true') query.isAccessible = true;

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 50;

    const rooms = await Room.find(query)
      .populate('building', 'name code colorScheme')
      .select('-schedule')
      .sort('floor roomNumber')
      .skip((page - 1) * limit)
      .limit(limit)
      .lean();

    const total = await Room.countDocuments(query);

    res.json({
      success: true,
      count: rooms.length,
      total,
      page,
      pages: Math.ceil(total / limit),
      data: rooms
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/rooms/:id  - Single room with full details (FR5.1 - POI tap)
router.get('/:id', async (req, res) => {
  try {
    const room = await Room.findById(req.params.id)
      .populate('building', 'name code colorScheme location operatingHours')
      .populate('facultyAssigned', 'name email department profilePicture vitId')
      .lean();

    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    // Increment visit count
    await Room.findByIdAndUpdate(req.params.id, { $inc: { 'stats.totalVisits': 1 } });

    res.json({ success: true, data: room });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/rooms/:id/schedule  - Room timetable
router.get('/:id/schedule', async (req, res) => {
  try {
    const room = await Room.findById(req.params.id).select('roomNumber name schedule').lean();
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    const today = new Date().toLocaleDateString('en-US', { weekday: 'short' });
    const todaySchedule = room.schedule?.filter(s => s.day === today) || [];

    res.json({
      success: true,
      data: {
        room: { id: room._id, number: room.roomNumber, name: room.name },
        today: todaySchedule,
        fullSchedule: room.schedule
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
