// ─── A* Pathfinding Algorithm (FR3.1) ────────────────────────────────────────
// Implements the A* algorithm on the campus navigation graph stored in MongoDB

const { PathSegment, Room } = require('../models/Room');
const Building = require('../models/Building');

class PriorityQueue {
  constructor() {
    this.heap = [];
  }
  push(item, priority) {
    this.heap.push({ item, priority });
    this.heap.sort((a, b) => a.priority - b.priority);
  }
  pop() {
    return this.heap.shift()?.item;
  }
  get size() { return this.heap.length; }
  isEmpty() { return this.heap.length === 0; }
}

// Heuristic: Euclidean distance estimate in meters using room positions
function heuristic(roomA, roomB) {
  if (!roomA?.position || !roomB?.position) return 0;
  const dx = (roomA.position.x - roomB.position.x);
  const dy = (roomA.position.y - roomB.position.y);
  const floorPenalty = Math.abs((roomA.floor || 0) - (roomB.floor || 0)) * 30; // ~30s per floor
  return Math.sqrt(dx * dx + dy * dy) * 0.5 + floorPenalty;
}

// Build adjacency list from PathSegment collection
async function buildGraph(buildingId, routeType = 'fastest') {
  const query = { isBlocked: false };
  if (buildingId) query.building = buildingId;

  // For wheelchair route, exclude non-accessible segments
  if (routeType === 'wheelchair') query.isAccessible = true;

  const segments = await PathSegment.find(query).lean();
  const graph = new Map();

  for (const seg of segments) {
    const from = seg.fromNode.toString();
    const to = seg.toNode.toString();

    // Cost depends on route type
    const cost = routeType === 'shortest'
      ? seg.distanceMeters
      : seg.estimatedTimeSeconds;

    if (!graph.has(from)) graph.set(from, []);
    graph.get(from).push({ neighbor: to, cost, segment: seg });

    if (seg.isBidirectional) {
      if (!graph.has(to)) graph.set(to, []);
      graph.get(to).push({ neighbor: from, cost, segment: seg });
    }
  }
  return graph;
}

// Core A* Search
async function astar(startId, goalId, routeType = 'fastest') {
  const startStr = startId.toString();
  const goalStr = goalId.toString();

  // Fetch all rooms for heuristic calculation
  const rooms = await Room.find({}).select('_id position floor').lean();
  const roomMap = new Map(rooms.map(r => [r._id.toString(), r]));

  const graph = await buildGraph(null, routeType);

  const openSet = new PriorityQueue();
  openSet.push(startStr, 0);

  const cameFrom = new Map();
  const gScore = new Map();
  const fScore = new Map();
  const pathSegments = new Map();  // Track which segment was used

  gScore.set(startStr, 0);
  fScore.set(startStr, heuristic(roomMap.get(startStr), roomMap.get(goalStr)));

  const visited = new Set();

  while (!openSet.isEmpty()) {
    const current = openSet.pop();

    if (current === goalStr) {
      return reconstructPath(cameFrom, pathSegments, current, roomMap, gScore.get(goalStr), routeType);
    }

    if (visited.has(current)) continue;
    visited.add(current);

    const neighbors = graph.get(current) || [];
    for (const { neighbor, cost, segment } of neighbors) {
      if (visited.has(neighbor)) continue;

      const tentativeG = (gScore.get(current) || Infinity) + cost;

      if (tentativeG < (gScore.get(neighbor) || Infinity)) {
        cameFrom.set(neighbor, current);
        pathSegments.set(neighbor, segment);
        gScore.set(neighbor, tentativeG);
        const h = heuristic(roomMap.get(neighbor), roomMap.get(goalStr));
        fScore.set(neighbor, tentativeG + h);
        openSet.push(neighbor, fScore.get(neighbor));
      }
    }
  }

  return null; // No path found (FR8.2)
}

function reconstructPath(cameFrom, pathSegments, current, roomMap, totalCost, routeType) {
  const path = [];
  const steps = [];
  let totalDistanceMeters = 0;
  let totalTimeSeconds = 0;

  let node = current;
  while (cameFrom.has(node)) {
    path.unshift(node);
    const seg = pathSegments.get(node);
    if (seg) {
      totalDistanceMeters += seg.distanceMeters || 0;
      totalTimeSeconds += seg.estimatedTimeSeconds || 0;
      steps.unshift(...(seg.waypoints || []).map(wp => ({
        instruction: wp.instruction || generateInstruction(seg.pathType),
        distanceMeters: seg.distanceMeters,
        floor: wp.floor || 0,
        pathType: seg.pathType
      })));
    }
    node = cameFrom.get(node);
  }
  path.unshift(node); // Add start

  return {
    path,
    steps: steps.length ? steps : [{ instruction: 'Proceed to destination', distanceMeters: totalDistanceMeters }],
    totalDistanceMeters: Math.round(totalDistanceMeters),
    estimatedTimeSeconds: Math.round(totalTimeSeconds),
    routeType
  };
}

function generateInstruction(pathType) {
  const instructions = {
    corridor: 'Continue straight',
    staircase_up: 'Go up the stairs',
    staircase_down: 'Go down the stairs',
    elevator_up: 'Take elevator up',
    elevator_down: 'Take elevator down',
    outdoor_path: 'Continue on outdoor path',
    ramp: 'Use the ramp',
    bridge: 'Cross the bridge'
  };
  return instructions[pathType] || 'Continue forward';
}

// ─── Route Controller Functions ───────────────────────────────────────────────

// GET /api/navigation/route
const getRoute = async (req, res) => {
  try {
    const { from, to, type = 'fastest' } = req.query;

    if (!from || !to) {
      return res.status(400).json({
        success: false,
        error: 'from and to room IDs are required'
      });
    }

    const validTypes = ['fastest', 'shortest', 'wheelchair'];
    if (!validTypes.includes(type)) {
      return res.status(400).json({
        success: false,
        error: `Invalid route type. Use one of: ${validTypes.join(', ')}`
      });
    }

    // Verify rooms exist
    const [fromRoom, toRoom] = await Promise.all([
      Room.findById(from).populate('building', 'name code'),
      Room.findById(to).populate('building', 'name code')
    ]);

    if (!fromRoom) return res.status(404).json({ success: false, error: 'Starting room not found' });
    if (!toRoom) return res.status(404).json({ success: false, error: 'Destination room not found' });

    if (toRoom.isClosed) {
      return res.status(400).json({
        success: false,
        error: `Destination is currently closed: ${toRoom.closureNote || 'Temporarily unavailable'}`,
        alternatives: []
      });
    }

    // Run A* algorithm
    const route = await astar(from, to, type);

    if (!route) {
      return res.status(404).json({
        success: false,
        error: 'No pedestrian path exists between these locations',
        suggestion: 'Try a different route type or check if rooms are in the same building'
      });
    }

    // Generate 3 route alternatives (FR3.2)
    const alternatives = await Promise.all(
      validTypes
        .filter(t => t !== type)
        .map(t => astar(from, to, t).catch(() => null))
    );

    // Populate path room details
    const populatedPath = await Room.find({ _id: { $in: route.path } })
      .select('roomNumber name floor building position')
      .populate('building', 'name code colorScheme')
      .lean();

    const roomLookup = new Map(populatedPath.map(r => [r._id.toString(), r]));
    const detailedPath = route.path.map(id => roomLookup.get(id)).filter(Boolean);

    return res.json({
      success: true,
      data: {
        from: { id: fromRoom._id, label: fromRoom.fullLabel || fromRoom.roomNumber, floor: fromRoom.floor, building: fromRoom.building },
        to: { id: toRoom._id, label: toRoom.fullLabel || toRoom.roomNumber, floor: toRoom.floor, building: toRoom.building },
        route: {
          ...route,
          path: detailedPath,
          etaLabel: formatETA(route.estimatedTimeSeconds),
          distanceLabel: formatDistance(route.totalDistanceMeters)
        },
        alternatives: alternatives.filter(Boolean).map(alt => ({
          ...alt,
          etaLabel: formatETA(alt.estimatedTimeSeconds),
          distanceLabel: formatDistance(alt.totalDistanceMeters)
        }))
      }
    });

  } catch (error) {
    console.error('Route computation error:', error);
    res.status(500).json({ success: false, error: 'Route computation failed' });
  }
};

function formatETA(seconds) {
  if (seconds < 60) return `${seconds}s`;
  const mins = Math.round(seconds / 60);
  return mins === 1 ? '1 min' : `${mins} mins`;
}

function formatDistance(meters) {
  if (meters < 1000) return `${meters}m`;
  return `${(meters / 1000).toFixed(1)}km`;
}

// GET /api/navigation/nearby  - Find nearby POIs
const getNearbyPOIs = async (req, res) => {
  try {
    const { roomId, radius = 100, types } = req.query;

    if (!roomId) {
      return res.status(400).json({ success: false, error: 'roomId is required' });
    }

    const room = await Room.findById(roomId);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    const query = {
      building: room.building,
      floor: room.floor,
      _id: { $ne: roomId },
      isActive: true
    };

    if (types) {
      query.type = { $in: types.split(',') };
    }

    const nearbyRooms = await Room.find(query)
      .select('roomNumber name type floor position capacity equipment isOccupied')
      .populate('building', 'name code')
      .limit(20)
      .lean();

    return res.json({ success: true, data: nearbyRooms });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

module.exports = { getRoute, getNearbyPOIs, astar };
