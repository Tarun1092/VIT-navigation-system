const mongoose = require('mongoose');

const buildingSchema = new mongoose.Schema({
  // Core Identity
  name: {
    type: String,
    required: [true, 'Building name is required'],
    trim: true,
    unique: true
  },
  code: {
    type: String,
    required: [true, 'Building code is required'],
    uppercase: true,
    trim: true,
    unique: true   // e.g. "TT", "GDN", "SJT", "MB"
  },
  fullName: { type: String, trim: true },  // e.g. "Tech Tower"
  school: {
    type: String,
    enum: ['SCOPE', 'SELECT', 'SENSE', 'SMEC', 'SSL', 'SAS', 'SBE', 'VITSBS', 'OTHER'],
    default: 'OTHER'
  },

  // Visual Theming (FR1.2)
  colorScheme: {
    primary: { type: String, default: '#3B82F6' },    // Tailwind blue-500
    secondary: { type: String, default: '#EFF6FF' },
    mapPin: { type: String, default: '#2563EB' }
  },

  // Location (GeoJSON for MongoDB geospatial queries)
  location: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number],   // [longitude, latitude]
      required: true,
      validate: {
        validator: (v) => v.length === 2,
        message: 'Coordinates must have [longitude, latitude]'
      }
    }
  },

  // Physical Structure
  totalFloors: { type: Number, default: 1, min: 1 },
  hasElevator: { type: Boolean, default: false },
  isAccessible: { type: Boolean, default: true },
  yearBuilt: { type: Number },
  areaSquareMeters: { type: Number },

  // Campus Layout
  nearbyLandmarks: [{ type: String }],
  entrances: [{
    name: { type: String },
    coordinates: { type: [Number] },
    isMainEntrance: { type: Boolean, default: false },
    isAccessible: { type: Boolean, default: false }
  }],

  // Facilities
  facilities: [{
    type: String,
    enum: ['canteen', 'atm', 'pharmacy', 'restroom', 'prayer_room', 'first_aid', 'parking', 'wifi', 'gym']
  }],

  // Operating Hours
  operatingHours: {
    weekdays: { open: { type: String, default: '07:00' }, close: { type: String, default: '22:00' } },
    saturday: { open: { type: String, default: '07:00' }, close: { type: String, default: '18:00' } },
    sunday: { open: { type: String, default: '09:00' }, close: { type: String, default: '14:00' } }
  },

  // Status
  isActive: { type: Boolean, default: true },
  isUnderConstruction: { type: Boolean, default: false },
  constructionNote: { type: String, default: '' },

  // Floor Plans
  floorPlans: [{
    floorNumber: { type: Number },
    floorLabel: { type: String },  // e.g. "Ground Floor", "1st Floor"
    imageUrl: { type: String },
    svgData: { type: String }      // Inline SVG for rendering
  }],

  // Statistics (FR7.3)
  stats: {
    totalVisits: { type: Number, default: 0 },
    peakHour: { type: String, default: '09:00' }
  },

  description: { type: String, default: '' },
  imageUrl: { type: String, default: '' },
  thumbnailUrl: { type: String, default: '' }

}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// ─── Geospatial Index ─────────────────────────────────────────────────────────
buildingSchema.index({ location: '2dsphere' });
buildingSchema.index({ code: 1 });
buildingSchema.index({ school: 1 });
buildingSchema.index({ isActive: 1 });
buildingSchema.index({ name: 'text', fullName: 'text', code: 'text' });

module.exports = mongoose.model('Building', buildingSchema);
