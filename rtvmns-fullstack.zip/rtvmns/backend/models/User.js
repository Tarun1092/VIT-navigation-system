const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  // Identity
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [100, 'Name cannot exceed 100 characters']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Invalid email format']
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters'],
    select: false
  },

  // VIT Specific
  vitId: {
    type: String,
    trim: true,
    sparse: true,
    uppercase: true  // e.g., 24MID0244
  },
  role: {
    type: String,
    enum: ['student', 'faculty', 'staff', 'visitor', 'admin'],
    default: 'student'
  },
  department: {
    type: String,
    enum: ['CSE', 'ECE', 'EEE', 'MECH', 'CIVIL', 'IT', 'BIOTECH', 'CHEM', 'MANAGEMENT', 'OTHER'],
    default: 'OTHER'
  },
  school: { type: String, trim: true },    // e.g. "School of Computer Science and Engineering"

  // Personalization (FR6)
  bookmarks: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bookmark'
  }],
  preferences: {
    preferWheelchairRoute: { type: Boolean, default: false },
    defaultRouteType: {
      type: String,
      enum: ['fastest', 'shortest', 'wheelchair'],
      default: 'fastest'
    },
    voiceNavigation: { type: Boolean, default: true },
    theme: { type: String, enum: ['light', 'dark', 'auto'], default: 'auto' }
  },

  // Navigation Analytics
  navigationStats: {
    totalTrips: { type: Number, default: 0 },
    totalDistanceMeters: { type: Number, default: 0 },
    totalTimeSavedSeconds: { type: Number, default: 0 },
    favoriteBuilding: { type: String, default: '' }
  },

  // ML-based suggestion (FR6.2)
  frequentDestinations: [{
    roomId: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
    visitCount: { type: Number, default: 0 },
    lastVisited: { type: Date }
  }],

  // Account
  isActive: { type: Boolean, default: true },
  isEmailVerified: { type: Boolean, default: false },
  profilePicture: { type: String, default: '' },
  lastLogin: { type: Date },
  passwordChangedAt: { type: Date }

}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// ─── Indexes ──────────────────────────────────────────────────────────────────
userSchema.index({ email: 1 });
userSchema.index({ vitId: 1 });
userSchema.index({ role: 1 });

// ─── Virtual: Full display name ───────────────────────────────────────────────
userSchema.virtual('displayName').get(function () {
  return this.vitId ? `${this.name} (${this.vitId})` : this.name;
});

// ─── Pre-save: Hash password ──────────────────────────────────────────────────
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  this.passwordChangedAt = new Date();
  next();
});

// ─── Methods ──────────────────────────────────────────────────────────────────
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

userSchema.methods.changedPasswordAfter = function (JWTTimestamp) {
  if (this.passwordChangedAt) {
    const changedTimestamp = parseInt(this.passwordChangedAt.getTime() / 1000, 10);
    return JWTTimestamp < changedTimestamp;
  }
  return false;
};

// Remove password from JSON output
userSchema.set('toJSON', {
  transform: (doc, ret) => {
    delete ret.password;
    delete ret.__v;
    return ret;
  }
});

module.exports = mongoose.model('User', userSchema);
