// js/app.js - Main Application Orchestrator

// ─── Room Viewer (FR5.1 - POI Details) ────────────────────────────────────────
const RoomViewer = {
  currentRoom: null,

  async showRoom(roomId) {
    try {
      UI.showLoading('Loading room details...');
      const { data } = await api.getRoom(roomId);
      RoomViewer.currentRoom = data;
      RoomViewer.renderModal(data);
      document.getElementById('room-modal').classList.remove('hidden');
    } catch (err) {
      UI.showToast(`Error loading room: ${err.message}`, 'error');
    } finally {
      UI.hideLoading();
    }
  },

  renderModal(room) {
    const typeIcons = {
      classroom: '🏫', lab: '🔬', faculty_office: '👨‍🏫', hod_office: '👔',
      seminar_hall: '🎭', auditorium: '🎪', library: '📚', canteen: '🍽️',
      washroom: '🚻', staircase: '🪜', elevator: '🛗', other: '📍'
    };

    document.getElementById('modal-room-type-icon').textContent = typeIcons[room.type] || '📍';
    document.getElementById('modal-room-number').textContent = room.roomNumber;
    document.getElementById('modal-room-name').textContent = room.name || '';
    document.getElementById('modal-building-name').textContent =
      room.building?.name || room.building?.code || 'Building';
    document.getElementById('modal-floor').textContent =
      room.floor === 0 ? 'Ground' : `Floor ${room.floor}`;
    document.getElementById('modal-capacity').textContent =
      room.capacity ? `${room.capacity} seats` : 'N/A';
    document.getElementById('modal-accessible').textContent =
      room.isAccessible ? '✅ Yes' : '❌ No';
    document.getElementById('modal-current-class').textContent =
      room.currentCourse || (room.isOccupied ? 'Class in progress' : 'None');

    // Occupancy badge
    const badge = document.getElementById('modal-occupancy');
    badge.textContent = room.isOccupied ? '🔴 Occupied' : '🟢 Available';
    badge.className = `occupancy-badge ${room.isOccupied ? 'occupied' : 'available'}`;

    // Equipment tags
    const equipEl = document.getElementById('modal-equipment');
    equipEl.innerHTML = '';
    if (room.equipment?.length) {
      room.equipment.forEach(eq => {
        const tag = document.createElement('span');
        tag.className = 'equip-tag';
        tag.textContent = eq.replace('_', ' ');
        equipEl.appendChild(tag);
      });
    } else {
      equipEl.innerHTML = '<span class="equip-tag">Standard</span>';
    }

    // Faculty (FR5.3)
    const facultySection = document.getElementById('faculty-section');
    const facultyEl = document.getElementById('modal-faculty');
    if (room.facultyAssigned?.length) {
      facultySection.classList.remove('hidden');
      facultyEl.innerHTML = '';
      room.facultyAssigned.forEach(faculty => {
        const initials = faculty.name?.split(' ').map(n => n[0]).join('').slice(0, 2) || '??';
        const div = document.createElement('div');
        div.className = 'faculty-item';
        div.innerHTML = `
          <div class="faculty-avatar">${initials}</div>
          <div class="faculty-info">
            <div class="faculty-name">${faculty.name}</div>
            <div class="faculty-dept">${faculty.department || ''} · ${faculty.email || ''}</div>
          </div>
        `;
        facultyEl.appendChild(div);
      });
    } else {
      facultySection.classList.add('hidden');
    }

    // Schedule
    const scheduleEl = document.getElementById('modal-schedule');
    scheduleEl.innerHTML = '';
    const today = new Date().toLocaleDateString('en-US', { weekday: 'short' });
    const todaySchedule = room.schedule?.filter(s => s.day === today) || [];

    if (todaySchedule.length) {
      todaySchedule.forEach(s => {
        const div = document.createElement('div');
        div.className = 'schedule-item';
        div.innerHTML = `
          <span class="schedule-time">${s.startTime}–${s.endTime}</span>
          <div>
            <div class="schedule-course">${s.courseName || s.courseCode}</div>
            <div style="font-size:0.72rem;color:var(--text-muted)">${s.courseCode || ''}</div>
          </div>
        `;
        scheduleEl.appendChild(div);
      });
    } else {
      scheduleEl.innerHTML = '<p class="empty-state small">No classes today</p>';
    }

    // Bind modal action buttons
    document.getElementById('modal-nav-btn').onclick = () => {
      document.getElementById('to-input').value = room.roomNumber;
      Search.selectedTo = room;
      document.getElementById('room-modal').classList.add('hidden');
      UI.showToast(`Destination set to ${room.roomNumber}`, 'info');
    };

    document.getElementById('navigate-to-room-btn').onclick = () => {
      document.getElementById('to-input').value = room.roomNumber;
      Search.selectedTo = room;
      document.getElementById('room-modal').classList.add('hidden');
    };

    document.getElementById('bookmark-room-btn').onclick = () => {
      Bookmarks.add(room._id);
    };

    document.getElementById('modal-nearby-btn').onclick = async () => {
      UI.showToast('Loading nearby rooms...', 'info');
      try {
        const { data } = await api.getNearby(room._id);
        if (data.length) {
          UI.showToast(`Found ${data.length} nearby rooms`, 'success');
        }
      } catch {}
    };

    document.getElementById('close-room-modal').onclick = () => {
      document.getElementById('room-modal').classList.add('hidden');
    };
  },

  async loadBuildingRooms(buildingId) {
    try {
      const { data } = await api.getBuilding(buildingId);
      App.renderBuildingDetail(data);
    } catch (err) {
      UI.showToast(`Error: ${err.message}`, 'error');
    }
  },

  async loadFloorRooms(buildingId, floor) {
    UI.showToast(`Loading floor ${floor === 0 ? 'G' : floor}...`, 'info');
    try {
      const { data } = await api.getRooms({ building: buildingId, floor });
      // Could render rooms on indoor map here
    } catch {}
  }
};

// ─── Main Application ──────────────────────────────────────────────────────────
const App = {
  buildings: [],

  async init() {
    UI.initTheme();
    UI.initSidebar();
    MapManager.init();
    Search.init();

    document.getElementById('voice-toggle').addEventListener('click', Navigation.toggleVoice);

    // Close modals on overlay click
    document.getElementById('room-modal').addEventListener('click', (e) => {
      if (e.target === e.currentTarget) e.currentTarget.classList.add('hidden');
    });

    // Init auth (may auto-login from stored token)
    await Auth.init();
  },

  async onLogin() {
    // Load buildings on the map
    await App.loadBuildings();
    await Bookmarks.load();

    // Try to get user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => MapManager.setUserLocation(pos.coords.latitude, pos.coords.longitude),
        () => {} // Silent fail
      );
    }

    // Show smart suggestions
    App.loadSuggestions();
  },

  async loadBuildings(school = 'all') {
    try {
      const filters = school !== 'all' ? { school } : {};
      const { data } = await api.getBuildings(filters);
      App.buildings = data;

      // Update map markers
      MapManager.addBuildingMarkers(data);

      // Render sidebar list
      App.renderBuildingsList(data);
    } catch (err) {
      console.error('Failed to load buildings:', err);
      // Show demo state
      App.renderBuildingsList([]);
    }
  },

  renderBuildingsList(buildings) {
    const list = document.getElementById('buildings-list');
    list.innerHTML = '';

    if (!buildings.length) {
      list.innerHTML = `
        <div style="text-align:center;padding:1rem;color:var(--text-muted);">
          <div style="font-size:2rem;">🏛️</div>
          <p style="font-size:0.85rem;margin-top:0.5rem;">
            Connect backend to see live buildings.<br>
            <a href="#" onclick="App.showConnectionGuide()" style="color:var(--color-primary)">Setup guide →</a>
          </p>
        </div>`;
      return;
    }

    buildings.forEach(building => {
      const color = building.colorScheme?.primary || '#3B82F6';
      const div = document.createElement('div');
      div.className = 'building-card';
      div.innerHTML = `
        <div class="building-color-dot" style="background:${color}"></div>
        <div class="building-card-info">
          <div class="building-code">${building.code}</div>
          <div class="building-card-name">${building.name}</div>
          <div class="building-meta">${building.totalFloors || 1}F · ${building.school || ''}</div>
        </div>
        <button class="building-nav-btn" title="Navigate to ${building.name}">
          <ion-icon name="navigate-outline"></ion-icon>
        </button>
      `;

      div.addEventListener('click', () => {
        if (!building.location?.coordinates) return;
        const [lng, lat] = building.location.coordinates;
        MapManager.map.setView([lat, lng], 18, { animate: true });
        MapManager.currentBuilding = building;
        MapManager.showFloorSelector(building);
      });

      div.querySelector('.building-nav-btn').addEventListener('click', async (e) => {
        e.stopPropagation();
        document.getElementById('to-input').value = building.name;
        Search.selectedTo = { _id: building._id, roomNumber: building.name, name: building.name };
        UI.showToast(`Destination: ${building.name}`, 'info');
      });

      list.appendChild(div);
    });

    // Building filter chips
    document.querySelectorAll('.filter-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        App.loadBuildings(chip.dataset.school);
      });
    });
  },

  renderBuildingDetail(building) {
    // Build a simple indoor floor plan view
    const overlay = document.getElementById('indoor-overlay');
    const mapCanvas = document.getElementById('indoor-map');
    document.getElementById('indoor-building-name').textContent = building.name;

    overlay.classList.remove('hidden');

    const floor0Rooms = building.roomsByFloor?.[0] || [];
    mapCanvas.innerHTML = '';

    if (!floor0Rooms.length) {
      mapCanvas.innerHTML = '<p style="color:var(--text-muted)">No room data available for this building.</p>';
      return;
    }

    // Simple grid floor plan
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 800 600');
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', '100%');
    svg.style.background = 'var(--bg-base)';

    // Building outline
    const outline = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    outline.setAttribute('x', 20); outline.setAttribute('y', 20);
    outline.setAttribute('width', 760); outline.setAttribute('height', 560);
    outline.setAttribute('rx', 10);
    outline.setAttribute('fill', 'none');
    outline.setAttribute('stroke', building.colorScheme?.primary || '#3B82F6');
    outline.setAttribute('stroke-width', 3);
    svg.appendChild(outline);

    // Render rooms
    floor0Rooms.slice(0, 20).forEach((room, i) => {
      const col = i % 5;
      const row = Math.floor(i / 5);
      const x = 50 + col * 145;
      const y = 60 + row * 120;
      const color = building.colorScheme?.primary || '#3B82F6';

      const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      g.style.cursor = 'pointer';

      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', x); rect.setAttribute('y', y);
      rect.setAttribute('width', 125); rect.setAttribute('height', 90);
      rect.setAttribute('rx', 6);
      rect.setAttribute('fill', room.isOccupied ? '#FEF2F2' : '#F0FDF4');
      rect.setAttribute('stroke', color);
      rect.setAttribute('stroke-width', 1.5);

      const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      text.setAttribute('x', x + 62); text.setAttribute('y', y + 35);
      text.setAttribute('text-anchor', 'middle');
      text.setAttribute('font-size', '13');
      text.setAttribute('font-weight', '700');
      text.setAttribute('fill', '#0F172A');
      text.textContent = room.roomNumber;

      const subtext = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      subtext.setAttribute('x', x + 62); subtext.setAttribute('y', y + 53);
      subtext.setAttribute('text-anchor', 'middle');
      subtext.setAttribute('font-size', '9');
      subtext.setAttribute('fill', '#64748B');
      subtext.textContent = room.type?.replace('_', ' ') || '';

      const statusDot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      statusDot.setAttribute('cx', x + 110); statusDot.setAttribute('cy', y + 15);
      statusDot.setAttribute('r', 5);
      statusDot.setAttribute('fill', room.isOccupied ? '#EF4444' : '#10B981');

      g.appendChild(rect);
      g.appendChild(text);
      g.appendChild(subtext);
      g.appendChild(statusDot);

      g.addEventListener('click', () => RoomViewer.showRoom(room._id));

      svg.appendChild(g);
    });

    mapCanvas.appendChild(svg);
  },

  focusBuilding(building) {
    if (building.location?.coordinates) {
      const [lng, lat] = building.location.coordinates;
      MapManager.map.setView([lat, lng], 18, { animate: true });
      MapManager.currentBuilding = building;
      MapManager.showFloorSelector(building);
    }
  },

  async loadSuggestions() {
    if (!Auth.user || Auth.user.role === 'visitor') return;
    try {
      const { data } = await api.getSuggestions();
      if (data.suggestions?.length) {
        UI.showToast(`💡 ${data.contextHint}`, 'info', 5000);
      }
    } catch {}
  },

  showConnectionGuide() {
    UI.showToast('Start backend: cd backend && npm install && npm run seed && npm start', 'info', 8000);
  }
};

// ─── Bootstrap ─────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  App.init().catch(err => {
    console.error('App init failed:', err);
    // Show graceful degraded state
    document.getElementById('auth-modal').classList.remove('hidden');
  });
});
