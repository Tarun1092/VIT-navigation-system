// js/bookmarks.js - Bookmark Management (FR6.1)
const Bookmarks = {
  data: [],

  async load() {
    if (!Auth.user || Auth.user.role === 'visitor') return;
    try {
      const { data } = await api.getBookmarks();
      Bookmarks.data = data;
      Bookmarks.render();
    } catch {}
  },

  render() {
    const list = document.getElementById('bookmarks-list');
    const count = document.getElementById('bookmark-count');
    count.textContent = Bookmarks.data.length;

    if (!Bookmarks.data.length) {
      list.innerHTML = '<p class="empty-state">No bookmarks yet. Tap ⭐ on a room to save it.</p>';
      return;
    }

    list.innerHTML = '';
    Bookmarks.data.forEach(bm => {
      const room = bm.room;
      if (!room) return;

      const div = document.createElement('div');
      div.className = 'bookmark-item';
      div.innerHTML = `
        <div class="bookmark-icon">${bm.icon || '📍'}</div>
        <div class="bookmark-info">
          <div class="bookmark-name">${bm.customName || room.roomNumber}</div>
          <div class="bookmark-sub">${room.building?.name || ''} · Floor ${room.floor ?? '?'}</div>
        </div>
        <button class="icon-btn delete-bm" data-id="${bm._id}" title="Remove">
          <ion-icon name="trash-outline" style="color:var(--color-danger)"></ion-icon>
        </button>
      `;

      div.addEventListener('click', (e) => {
        if (e.target.closest('.delete-bm')) return;
        RoomViewer.showRoom(room._id || room);
      });

      div.querySelector('.delete-bm').addEventListener('click', async (e) => {
        e.stopPropagation();
        await Bookmarks.remove(bm._id);
      });

      list.appendChild(div);
    });
  },

  async add(roomId) {
    if (!Auth.user || Auth.user.role === 'visitor') {
      UI.showToast('Login to bookmark rooms', 'warning');
      return;
    }
    try {
      await api.addBookmark(roomId);
      await Bookmarks.load();
      UI.showToast('Bookmarked! ⭐', 'success');
    } catch (err) {
      UI.showToast(err.message, 'error');
    }
  },

  async remove(bookmarkId) {
    try {
      await api.deleteBookmark(bookmarkId);
      Bookmarks.data = Bookmarks.data.filter(b => b._id !== bookmarkId);
      Bookmarks.render();
      UI.showToast('Bookmark removed', 'info');
    } catch (err) {
      UI.showToast(err.message, 'error');
    }
  }
};

// js/ui.js - UI Utilities
const UI = {
  showLoading(text = 'Loading...') {
    document.getElementById('loading-text').textContent = text;
    document.getElementById('loading-overlay').classList.remove('hidden');
  },

  hideLoading() {
    document.getElementById('loading-overlay').classList.add('hidden');
  },

  showToast(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    toast.className = `toast ${type}`;
    toast.textContent = `${icons[type] || ''} ${message}`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      toast.style.transition = '0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },

  initTheme() {
    const saved = localStorage.getItem('rtvmns_theme') || 'light';
    document.documentElement.dataset.theme = saved;
    document.getElementById('theme-icon').name = saved === 'dark' ? 'moon-outline' : 'sunny-outline';

    document.getElementById('theme-toggle').addEventListener('click', () => {
      const current = document.documentElement.dataset.theme;
      const next = current === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = next;
      localStorage.setItem('rtvmns_theme', next);
      document.getElementById('theme-icon').name = next === 'dark' ? 'moon-outline' : 'sunny-outline';
    });
  },

  initSidebar() {
    const sidebar = document.getElementById('sidebar');
    document.getElementById('sidebar-toggle').addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      if (window.innerWidth <= 768) {
        sidebar.classList.toggle('mobile-open');
      }
    });
  }
};
