// js/api.js - Centralized API client for RTVMNS backend
// Base URL - update if deploying to a server
const API_BASE = window.location.hostname === 'localhost'
  ? 'http://localhost:5000/api'
  : '/api';

class APIClient {
  constructor() {
    this.token = localStorage.getItem('rtvmns_token');
  }

  setToken(token) {
    this.token = token;
    if (token) localStorage.setItem('rtvmns_token', token);
    else localStorage.removeItem('rtvmns_token');
  }

  async request(endpoint, options = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...(this.token && { 'Authorization': `Bearer ${this.token}` }),
      ...options.headers
    };

    const config = {
      method: options.method || 'GET',
      headers,
      ...(options.body && { body: JSON.stringify(options.body) })
    };

    const res = await fetch(`${API_BASE}${endpoint}`, config);
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || data.message || `HTTP ${res.status}`);
    }
    return data;
  }

  // ─── Auth ────────────────────────────────────────────────────────────────
  async login(email, password) {
    const data = await this.request('/auth/login', {
      method: 'POST',
      body: { email, password }
    });
    if (data.data?.token) this.setToken(data.data.token);
    return data;
  }

  async register(payload) {
    const data = await this.request('/auth/register', {
      method: 'POST', body: payload
    });
    if (data.data?.token) this.setToken(data.data.token);
    return data;
  }

  async getMe() { return this.request('/auth/me'); }

  async updatePreferences(prefs) {
    return this.request('/auth/preferences', { method: 'PATCH', body: prefs });
  }

  logout() { this.setToken(null); }

  // ─── Buildings ───────────────────────────────────────────────────────────
  async getBuildings(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return this.request(`/buildings${params ? '?' + params : ''}`);
  }

  async getBuilding(id) { return this.request(`/buildings/${id}`); }

  async getFloorPlan(buildingId, floor) {
    return this.request(`/buildings/${buildingId}/floorplan/${floor}`);
  }

  // ─── Rooms ───────────────────────────────────────────────────────────────
  async getRooms(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return this.request(`/rooms${params ? '?' + params : ''}`);
  }

  async getRoom(id) { return this.request(`/rooms/${id}`); }

  async getRoomSchedule(id) { return this.request(`/rooms/${id}/schedule`); }

  // ─── Search ──────────────────────────────────────────────────────────────
  async search(query, filters = {}) {
    const params = new URLSearchParams({ q: query, ...filters }).toString();
    return this.request(`/search?${params}`);
  }

  async autocomplete(query) {
    return this.request(`/search/autocomplete?q=${encodeURIComponent(query)}`);
  }

  // ─── Navigation ──────────────────────────────────────────────────────────
  async getRoute(from, to, type = 'fastest') {
    return this.request(`/navigation/route?from=${from}&to=${to}&type=${type}`);
  }

  async getNearby(roomId, types = '') {
    return this.request(`/navigation/nearby?roomId=${roomId}${types ? '&types=' + types : ''}`);
  }

  async startNavSession(payload) {
    return this.request('/navigation/session', { method: 'POST', body: payload });
  }

  async getNavHistory() { return this.request('/navigation/history'); }

  // ─── Bookmarks ───────────────────────────────────────────────────────────
  async getBookmarks() { return this.request('/bookmarks'); }

  async addBookmark(roomId, customName = '', icon = '📍', color = '#3B82F6') {
    return this.request('/bookmarks', {
      method: 'POST',
      body: { roomId, customName, icon, color }
    });
  }

  async deleteBookmark(id) {
    return this.request(`/bookmarks/${id}`, { method: 'DELETE' });
  }

  // ─── Analytics ───────────────────────────────────────────────────────────
  async getAnalytics() { return this.request('/analytics/overview'); }

  async getSuggestions() { return this.request('/analytics/suggestions'); }

  // ─── Admin ───────────────────────────────────────────────────────────────
  async createBuilding(data) {
    return this.request('/admin/buildings', { method: 'POST', body: data });
  }

  async updateBuilding(id, data) {
    return this.request(`/admin/buildings/${id}`, { method: 'PUT', body: data });
  }

  async setRoomClosure(id, isClosed, closureNote = '') {
    return this.request(`/admin/rooms/${id}/closure`, {
      method: 'PATCH',
      body: { isClosed, closureNote }
    });
  }

  async setBuildingClosure(id, isUnderConstruction, constructionNote = '') {
    return this.request(`/admin/buildings/${id}/closure`, {
      method: 'PATCH',
      body: { isUnderConstruction, constructionNote }
    });
  }

  // Health check
  async healthCheck() { return this.request('/health'); }
}

// Global API client instance
window.api = new APIClient();
