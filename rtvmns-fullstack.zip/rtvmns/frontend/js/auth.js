// js/auth.js - Authentication Management
const Auth = {
  user: null,

  async init() {
    const token = localStorage.getItem('rtvmns_token');
    if (token) {
      try {
        const { data } = await api.getMe();
        Auth.setUser(data);
        Auth.hideModal();
      } catch {
        api.logout();
      }
    }
    Auth.bindEvents();
  },

  setUser(user) {
    Auth.user = user;
    // Update UI
    document.getElementById('header-username').textContent = user.name || 'User';
    document.getElementById('header-userrole').textContent = user.role || 'student';
    if (user.role === 'admin') {
      document.querySelectorAll('.admin-only').forEach(el => el.classList.remove('hidden'));
    }
  },

  hideModal() {
    document.getElementById('auth-modal').classList.add('hidden');
  },

  showModal() {
    document.getElementById('auth-modal').classList.remove('hidden');
  },

  bindEvents() {
    // Tab switching
    document.querySelectorAll('.auth-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`${tab.dataset.tab}-form`).classList.add('active');
      });
    });

    // Login
    document.getElementById('login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email').value;
      const password = document.getElementById('login-password').value;
      const errEl = document.getElementById('login-error');

      try {
        UI.showLoading('Signing in...');
        const { data } = await api.login(email, password);
        Auth.setUser(data.user);
        Auth.hideModal();
        UI.showToast(`Welcome, ${data.user.name}! 👋`, 'success');
        App.onLogin();
      } catch (err) {
        errEl.textContent = err.message;
        errEl.classList.remove('hidden');
      } finally {
        UI.hideLoading();
      }
    });

    // Register
    document.getElementById('register-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const errEl = document.getElementById('register-error');
      try {
        UI.showLoading('Creating account...');
        const { data } = await api.register({
          name: document.getElementById('reg-name').value,
          email: document.getElementById('reg-email').value,
          password: document.getElementById('reg-password').value,
          vitId: document.getElementById('reg-vitid').value,
          role: document.getElementById('reg-role').value,
          department: document.getElementById('reg-dept').value
        });
        Auth.setUser(data.user);
        Auth.hideModal();
        UI.showToast('Account created! Welcome! 🎉', 'success');
        App.onLogin();
      } catch (err) {
        errEl.textContent = err.message;
        errEl.classList.remove('hidden');
      } finally {
        UI.hideLoading();
      }
    });

    // Skip auth (guest)
    document.getElementById('skip-auth').addEventListener('click', () => {
      Auth.hideModal();
      Auth.user = { name: 'Guest', role: 'visitor' };
      document.getElementById('header-username').textContent = 'Guest';
      App.onLogin();
    });

    // Logout
    document.getElementById('logout-btn').addEventListener('click', (e) => {
      e.preventDefault();
      api.logout();
      Auth.user = null;
      document.getElementById('user-dropdown').classList.add('hidden');
      Auth.showModal();
      UI.showToast('Logged out', 'info');
    });

    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(btn => {
      btn.addEventListener('click', () => {
        const input = document.getElementById(btn.dataset.target);
        input.type = input.type === 'password' ? 'text' : 'password';
        btn.querySelector('ion-icon').name =
          input.type === 'password' ? 'eye-outline' : 'eye-off-outline';
      });
    });

    // User dropdown toggle
    document.getElementById('user-menu-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      document.getElementById('user-dropdown').classList.toggle('hidden');
    });

    document.addEventListener('click', () => {
      document.getElementById('user-dropdown').classList.add('hidden');
    });
  }
};
