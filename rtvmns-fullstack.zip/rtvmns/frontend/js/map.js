// js/map.js - Interactive Leaflet Map with VIT Campus
const MapManager = {
  map: null,
  buildingMarkers: [],
  userMarker: null,
  routeLayer: null,
  currentBuilding: null,

  // VIT Vellore Campus Center Coordinates
  VIT_CENTER: [12.9696, 79.1521],
  VIT_ZOOM: 16,

  init() {
    // Initialize Leaflet map centered on VIT
    MapManager.map = L.map('map', {
      center: MapManager.VIT_CENTER,
      zoom: MapManager.VIT_ZOOM,
      zoomControl: false,  // We'll use custom controls
      attributionControl: true
    });

    // Add tile layer
    MapManager.setTileLayer('standard');

    // Custom zoom control position
    L.control.zoom({ position: 'bottomright' }).addTo(MapManager.map);

    // Map click handler
    MapManager.map.on('click', () => {
      document.getElementById('room-modal').classList.add('hidden');
    });

    // Map controls
    document.getElementById('recenter-btn').addEventListener('click', () => {
      MapManager.recenter();
    });

    document.getElementById('fullscreen-btn').addEventListener('click', () => {
      MapManager.toggleFullscreen();
    });

    document.getElementById('toggle-indoor-btn').addEventListener('click', () => {
      if (MapManager.currentBuilding) {
        RoomViewer.showIndoorPlan(MapManager.currentBuilding);
      } else {
        UI.showToast('Select a building first to view floor plan', 'info');
      }
    });

    // Close indoor overlay
    document.getElementById('close-indoor').addEventListener('click', () => {
      document.getElementById('indoor-overlay').classList.add('hidden');
    });
  },

  setTileLayer(type = 'standard') {
    if (MapManager._tileLayer) MapManager.map.removeLayer(MapManager._tileLayer);

    const tiles = {
      standard: {
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        attribution: '© <a href="https://openstreetmap.org">OpenStreetMap</a>'
      },
      satellite: {
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attribution: '© Esri World Imagery'
      }
    };

    const t = tiles[type] || tiles.standard;
    MapManager._tileLayer = L.tileLayer(t.url, { attribution: t.attribution, maxZoom: 21 });
    MapManager._tileLayer.addTo(MapManager.map);
  },

  addBuildingMarkers(buildings) {
    // Clear existing markers
    MapManager.buildingMarkers.forEach(m => MapManager.map.removeLayer(m));
    MapManager.buildingMarkers = [];

    buildings.forEach(building => {
      if (!building.location?.coordinates) return;

      const [lng, lat] = building.location.coordinates;
      const color = building.colorScheme?.primary || '#3B82F6';

      // Custom HTML marker
      const icon = L.divIcon({
        html: `
          <div class="building-marker">
            <div class="marker-pin" style="background:${color}"></div>
            <div class="marker-label" style="border: 2px solid ${color}">${building.code}</div>
          </div>
        `,
        className: '',
        iconSize: [46, 55],
        iconAnchor: [23, 55],
        popupAnchor: [0, -55]
      });

      const marker = L.marker([lat, lng], { icon })
        .bindPopup(MapManager.createBuildingPopup(building))
        .addTo(MapManager.map);

      marker.on('click', (e) => {
        e.originalEvent.stopPropagation();
        MapManager.currentBuilding = building;
        MapManager.map.setView([lat, lng], 18, { animate: true });
        // Show floor selector
        MapManager.showFloorSelector(building);
      });

      MapManager.buildingMarkers.push(marker);
    });
  },

  createBuildingPopup(building) {
    const color = building.colorScheme?.primary || '#3B82F6';
    return `
      <div style="min-width:180px; font-family: sans-serif;">
        <div style="font-size:0.7rem;font-weight:800;color:${color};text-transform:uppercase;letter-spacing:0.5px;">
          ${building.school || ''}
        </div>
        <div style="font-size:1rem;font-weight:700;margin:4px 0;">${building.name}</div>
        <div style="font-size:0.8rem;color:#64748b;">${building.totalFloors || 1} Floors · ${building.hasElevator ? 'Elevator ✓' : 'No Elevator'}</div>
        ${building.isAccessible ? '<div style="font-size:0.75rem;color:#059669;margin-top:4px;">♿ Accessible</div>' : ''}
        <button onclick="RoomViewer.loadBuildingRooms('${building._id}')"
          style="margin-top:8px;padding:5px 12px;background:${color};color:white;border:none;border-radius:4px;cursor:pointer;font-size:0.8rem;font-weight:600;">
          View Rooms →
        </button>
      </div>
    `;
  },

  showFloorSelector(building) {
    const selector = document.getElementById('floor-selector');
    const btnsContainer = document.getElementById('floor-buttons');
    btnsContainer.innerHTML = '';
    selector.classList.remove('hidden');

    const floors = building.totalFloors || 5;
    for (let i = floors - 1; i >= 0; i--) {
      const btn = document.createElement('button');
      btn.className = `floor-btn${i === 0 ? ' active' : ''}`;
      btn.textContent = i === 0 ? 'G' : i;
      btn.dataset.floor = i;
      btn.addEventListener('click', () => {
        document.querySelectorAll('.floor-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        RoomViewer.loadFloorRooms(building._id, i);
      });
      btnsContainer.appendChild(btn);
    }
  },

  showRoute(routeData) {
    if (MapManager.routeLayer) MapManager.map.removeLayer(MapManager.routeLayer);

    // Draw route polyline (simplified - real app would use actual GPS coordinates)
    const path = routeData.path || [];
    if (path.length < 2) return;

    // Create a dashed animated polyline on the map
    const routeCoords = path.map(room => {
      // Use room coordinates if available, otherwise use building coords with offset
      if (room.coordinates?.coordinates) {
        const [lng, lat] = room.coordinates.coordinates;
        return [lat, lng];
      }
      return null;
    }).filter(Boolean);

    if (routeCoords.length < 2) {
      // Fall back to drawing between building markers
      UI.showToast('Route calculated! Navigate using step-by-step instructions.', 'success');
      return;
    }

    MapManager.routeLayer = L.polyline(routeCoords, {
      color: '#2563EB',
      weight: 5,
      opacity: 0.8,
      dashArray: '10, 6',
      lineCap: 'round'
    }).addTo(MapManager.map);

    MapManager.map.fitBounds(MapManager.routeLayer.getBounds(), { padding: [40, 40] });
  },

  setUserLocation(lat, lng) {
    if (MapManager.userMarker) MapManager.map.removeLayer(MapManager.userMarker);

    const icon = L.divIcon({
      html: '<div class="user-location-marker"></div>',
      className: '',
      iconSize: [18, 18],
      iconAnchor: [9, 9]
    });

    MapManager.userMarker = L.marker([lat, lng], { icon })
      .bindPopup('<b>📍 You are here</b>')
      .addTo(MapManager.map);
  },

  recenter() {
    if (MapManager.userMarker) {
      MapManager.map.setView(MapManager.userMarker.getLatLng(), 18, { animate: true });
    } else {
      MapManager.map.setView(MapManager.VIT_CENTER, MapManager.VIT_ZOOM, { animate: true });
    }
  },

  clearRoute() {
    if (MapManager.routeLayer) {
      MapManager.map.removeLayer(MapManager.routeLayer);
      MapManager.routeLayer = null;
    }
  },

  toggleFullscreen() {
    const el = document.getElementById('map-container');
    if (!document.fullscreenElement) {
      el.requestFullscreen?.();
      document.getElementById('fullscreen-btn').querySelector('ion-icon').name = 'contract-outline';
    } else {
      document.exitFullscreen?.();
      document.getElementById('fullscreen-btn').querySelector('ion-icon').name = 'expand-outline';
    }
  }
};
