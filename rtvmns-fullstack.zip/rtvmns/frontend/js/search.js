// js/search.js - Search with autocomplete (FR2)
const Search = {
  selectedFrom: null,
  selectedTo: null,
  debounceTimer: null,

  init() {
    const mainSearch = document.getElementById('main-search');
    const resultsEl = document.getElementById('search-results');

    // Main search bar
    mainSearch.addEventListener('input', (e) => {
      clearTimeout(Search.debounceTimer);
      const q = e.target.value.trim();
      if (q.length < 2) {
        resultsEl.classList.add('hidden');
        return;
      }
      Search.debounceTimer = setTimeout(() => Search.doSearch(q), 300);
    });

    mainSearch.addEventListener('focus', (e) => {
      if (e.target.value.trim().length >= 2) resultsEl.classList.remove('hidden');
    });

    document.addEventListener('click', (e) => {
      if (!e.target.closest('#main-search-wrapper')) {
        resultsEl.classList.add('hidden');
      }
    });

    // Route input autocomplete
    Search.bindRouteInput('from-input', (room) => {
      Search.selectedFrom = room;
      UI.showToast(`From: ${room.roomNumber || room.name}`, 'info');
    });

    Search.bindRouteInput('to-input', (room) => {
      Search.selectedTo = room;
      UI.showToast(`To: ${room.roomNumber || room.name}`, 'info');
    });

    // Get directions button
    document.getElementById('get-route-btn').addEventListener('click', async () => {
      if (!Search.selectedFrom || !Search.selectedTo) {
        UI.showToast('Please select both start and destination rooms', 'warning');
        return;
      }
      const type = document.querySelector('.route-type-btn.active')?.dataset.type || 'fastest';
      const data = await Navigation.getRoute(Search.selectedFrom._id, Search.selectedTo._id, type);
      if (data) {
        // Auto-start navigation when route found
        document.getElementById('from-input').value = Search.selectedFrom.roomNumber || 'Start';
        document.getElementById('to-input').value = Search.selectedTo.roomNumber || 'Destination';
      }
    });

    // Swap route button
    document.getElementById('swap-route').addEventListener('click', () => {
      const tmp = Search.selectedFrom;
      Search.selectedFrom = Search.selectedTo;
      Search.selectedTo = tmp;

      const fromVal = document.getElementById('from-input').value;
      const toVal = document.getElementById('to-input').value;
      document.getElementById('from-input').value = toVal;
      document.getElementById('to-input').value = fromVal;
    });

    // Route type buttons
    document.querySelectorAll('.route-type-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.route-type-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });

    // Use my location
    document.getElementById('use-location-btn').addEventListener('click', () => {
      if (!navigator.geolocation) {
        UI.showToast('Geolocation not supported on this device', 'error');
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          MapManager.setUserLocation(pos.coords.latitude, pos.coords.longitude);
          document.getElementById('from-input').value = 'My Location';
          Search.selectedFrom = {
            _id: 'geolocation',
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            roomNumber: 'My Location'
          };
          UI.showToast('📍 Location found!', 'success');
        },
        () => UI.showToast('Could not get location. Enable GPS.', 'error')
      );
    });
  },

  bindRouteInput(inputId, onSelect) {
    const input = document.getElementById(inputId);
    let dropdown = null;

    input.addEventListener('input', async (e) => {
      clearTimeout(Search.debounceTimer);
      const q = e.target.value.trim();
      if (q.length < 2) {
        if (dropdown) { dropdown.remove(); dropdown = null; }
        return;
      }
      Search.debounceTimer = setTimeout(async () => {
        try {
          const { data } = await api.autocomplete(q);
          if (!data.length) return;

          if (dropdown) dropdown.remove();
          dropdown = document.createElement('div');
          dropdown.className = 'search-dropdown';
          dropdown.style.cssText = 'position:absolute;top:100%;left:0;right:0;z-index:300;';

          data.forEach(item => {
            const row = document.createElement('div');
            row.className = 'search-item';
            row.innerHTML = `
              <div class="search-item-icon" style="background:var(--bg-base)">${Search.getTypeEmoji(item.type)}</div>
              <div class="search-item-info">
                <div class="search-item-title">${item.label}</div>
                <div class="search-item-sub">${item.building} · Floor ${item.floor}</div>
              </div>
            `;
            row.addEventListener('click', () => {
              input.value = item.label;
              onSelect(item);
              dropdown.remove();
              dropdown = null;
            });
            dropdown.appendChild(row);
          });

          input.parentElement.style.position = 'relative';
          input.parentElement.appendChild(dropdown);
        } catch {}
      }, 250);
    });
  },

  async doSearch(query) {
    const resultsEl = document.getElementById('search-results');
    try {
      resultsEl.innerHTML = '<div class="search-item"><div style="color:var(--text-muted);font-size:0.85rem;width:100%;text-align:center;">Searching...</div></div>';
      resultsEl.classList.remove('hidden');

      const { data } = await api.search(query);
      Search.renderResults(data, resultsEl);
    } catch {
      resultsEl.classList.add('hidden');
    }
  },

  renderResults(results, container) {
    if (!results.length) {
      container.innerHTML = '<div class="search-item"><div style="color:var(--text-muted);font-size:0.85rem;padding:0.5rem;">No results found</div></div>';
      return;
    }

    container.innerHTML = '';
    results.slice(0, 8).forEach(item => {
      const isBuilding = item.resultType === 'building';
      const div = document.createElement('div');
      div.className = 'search-item';

      const color = item.colorScheme?.primary || '#3B82F6';
      const icon = isBuilding ? '🏢' : Search.getTypeEmoji(item.type);
      const label = isBuilding ? item.name : (item.name ? `${item.roomNumber} – ${item.name}` : item.roomNumber);
      const sub = isBuilding
        ? `${item.school || 'Academic Building'}`
        : `${item.building?.code || ''} · Floor ${item.floor ?? '?'}`;

      div.innerHTML = `
        <div class="search-item-icon" style="background:${color}20;color:${color}">${icon}</div>
        <div class="search-item-info">
          <div class="search-item-title">${label}</div>
          <div class="search-item-sub">${sub}</div>
        </div>
        <div class="search-item-badge">${isBuilding ? 'Building' : item.type?.replace('_', ' ') || 'Room'}</div>
      `;

      div.addEventListener('click', () => {
        container.classList.add('hidden');
        document.getElementById('main-search').value = '';
        if (isBuilding) {
          App.focusBuilding(item);
        } else {
          RoomViewer.showRoom(item._id);
        }
      });

      container.appendChild(div);
    });
  },

  getTypeEmoji(type) {
    const map = {
      classroom: '🏫', lab: '🔬', faculty_office: '👨‍🏫',
      hod_office: '👔', seminar_hall: '🎭', auditorium: '🎪',
      library: '📚', canteen: '🍽️', washroom: '🚻',
      staircase: '🪜', elevator: '🛗', other: '📍'
    };
    return map[type] || '📍';
  }
};
