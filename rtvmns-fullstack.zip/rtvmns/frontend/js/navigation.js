// js/navigation.js - Turn-by-turn navigation (FR3, FR4)
const Navigation = {
  active: false,
  sessionId: null,
  currentStep: 0,
  steps: [],
  voiceEnabled: true,
  synth: window.speechSynthesis,

  async getRoute(fromId, toId, type = 'fastest') {
    try {
      UI.showLoading('Computing route...');
      const { data } = await api.getRoute(fromId, toId, type);
      Navigation.displayRoute(data);
      if (data.route) MapManager.showRoute(data.route);
      return data;
    } catch (err) {
      UI.showToast(`Route error: ${err.message}`, 'error');
      return null;
    } finally {
      UI.hideLoading();
    }
  },

  displayRoute(data) {
    if (!data?.route) return;

    const { route, from, to } = data;

    document.getElementById('route-result').classList.remove('hidden');
    document.getElementById('route-time').textContent = route.etaLabel || '--';
    document.getElementById('route-dist').textContent = route.distanceLabel || '--';

    // Render step list
    const stepsEl = document.getElementById('route-steps');
    stepsEl.innerHTML = '';

    if (route.steps?.length) {
      route.steps.forEach((step, i) => {
        const icon = Navigation.getStepIcon(step.pathType || 'corridor');
        const div = document.createElement('div');
        div.className = 'route-step';
        div.innerHTML = `
          <div class="step-icon">${icon}</div>
          <div>
            <div style="font-weight:600;">${step.instruction || 'Continue forward'}</div>
            ${step.distanceMeters ? `<div style="font-size:0.75rem;color:var(--text-muted);">${step.distanceMeters}m</div>` : ''}
          </div>
        `;
        stepsEl.appendChild(div);
      });
    } else {
      stepsEl.innerHTML = `<div class="route-step">
        <div class="step-icon">🚶</div>
        <div>Walk from ${from?.label || 'Start'} to ${to?.label || 'Destination'}</div>
      </div>`;
    }

    Navigation.steps = route.steps || [];
  },

  startNavigation(route) {
    Navigation.active = true;
    Navigation.currentStep = 0;

    const banner = document.getElementById('nav-banner');
    banner.classList.remove('hidden');

    if (Navigation.steps.length > 0) {
      Navigation.announceStep(0);
    } else {
      document.getElementById('nav-next-step').textContent = 'Proceed to destination';
    }

    document.getElementById('end-nav-btn').addEventListener('click', Navigation.endNavigation, { once: true });
    UI.showToast('Navigation started! 🗺️', 'success');
  },

  announceStep(index) {
    const step = Navigation.steps[index];
    if (!step) return;

    const el = document.getElementById('nav-next-step');
    el.textContent = step.instruction || 'Continue forward';

    // Voice announcement (FR4.1)
    if (Navigation.voiceEnabled && Navigation.synth) {
      const utterance = new SpeechSynthesisUtterance(step.instruction);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      Navigation.synth.speak(utterance);
    }

    // Update progress
    const progress = ((index + 1) / Navigation.steps.length) * 100;
    document.getElementById('nav-progress').style.width = `${progress}%`;
  },

  getStepIcon(pathType) {
    const icons = {
      corridor: '🚶',
      staircase_up: '⬆️',
      staircase_down: '⬇️',
      elevator_up: '🛗',
      elevator_down: '🛗',
      outdoor_path: '🌿',
      ramp: '♿',
      bridge: '🌉'
    };
    return icons[pathType] || '➡️';
  },

  endNavigation() {
    Navigation.active = false;
    document.getElementById('nav-banner').classList.add('hidden');
    MapManager.clearRoute();
    document.getElementById('route-result').classList.add('hidden');
    Navigation.steps = [];
    Navigation.currentStep = 0;
    if (Navigation.synth) Navigation.synth.cancel();
    UI.showToast('Navigation ended', 'info');
  },

  toggleVoice() {
    Navigation.voiceEnabled = !Navigation.voiceEnabled;
    const icon = document.getElementById('voice-icon');
    icon.name = Navigation.voiceEnabled ? 'mic-outline' : 'mic-off-outline';
    UI.showToast(Navigation.voiceEnabled ? '🔊 Voice navigation on' : '🔇 Voice navigation off', 'info');
  }
};
