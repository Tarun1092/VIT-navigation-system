# 🗺️ RTVMNS — Real-Time VIT Map Navigation System

> Full-stack campus navigation system for Vellore Institute of Technology  
> **HTML + CSS + JS** (Frontend) · **Node.js + Express** (Backend) · **MongoDB** (Database)

---

## 📁 Project Structure

```
rtvmns/
├── backend/
│   ├── models/
│   │   ├── User.js               # User schema (student/faculty/admin)
│   │   ├── Building.js           # Building + GeoJSON schema
│   │   └── Room.js               # Room, PathSegment, Bookmark, NavSession
│   ├── routes/
│   │   ├── auth.js               # POST /login, /register, GET /me
│   │   ├── buildings.js          # GET /buildings, /:id, /:id/floorplan/:floor
│   │   ├── rooms.js              # GET /rooms, /:id, /:id/schedule
│   │   ├── search.js             # GET /search, /search/autocomplete
│   │   ├── navigation.js         # GET /route, /nearby · POST /session
│   │   ├── bookmarks.js          # CRUD bookmarks (max 20 per user)
│   │   ├── admin.js              # Admin-only CRUD + closures
│   │   └── analytics.js          # Overview, peak-traffic, suggestions
│   ├── controllers/
│   │   └── navigationController.js  # A* pathfinding algorithm
│   ├── middleware/
│   │   └── auth.js               # JWT protect, restrictTo, optionalAuth
│   ├── server.js                 # Express app + MongoDB connection
│   ├── seed.js                   # Database seeder (VIT buildings + rooms)
│   ├── package.json
│   └── .env.example
│
└── frontend/
    ├── index.html                # Single-page app shell
    ├── css/
    │   └── style.css             # Full design system (light/dark theme)
    └── js/
        ├── api.js                # Centralized API client
        ├── auth.js               # Login/register/logout
        ├── map.js                # Leaflet.js map management
        ├── navigation.js         # Turn-by-turn + voice navigation
        ├── search.js             # Fuzzy search + autocomplete
        ├── bookmarks.js          # Bookmark CRUD
        ├── ui.js                 # Toast, loading, theme, sidebar
        └── app.js                # Main orchestrator + RoomViewer
```

---

## 🚀 Quick Start

### 1. Prerequisites
- Node.js v18+
- MongoDB (local or Atlas)
- npm

### 2. Backend Setup
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI and API keys

# Seed database with VIT campus data
npm run seed

# Start development server
npm run dev
# → Server on http://localhost:5000
```

### 3. Frontend
```bash
# Option A: Via Node.js backend (recommended)
# Frontend is served at http://localhost:5000

# Option B: Live Server (VS Code extension)
# Open frontend/index.html with Live Server
# Update API_BASE in js/api.js to http://localhost:5000/api
```

### 4. Demo Credentials
| Role    | Email                 | Password      |
|---------|-----------------------|---------------|
| Admin   | admin@vit.ac.in       | admin123456   |
| Student | student@vit.ac.in     | student123    |

---

## 🔑 Required APIs & Services

### MANDATORY
| API | Purpose | Get it |
|-----|---------|--------|
| **MongoDB Atlas** or local MongoDB | Database | [mongodb.com](https://mongodb.com) |

### STRONGLY RECOMMENDED
| API | Purpose | Free Tier | Get it |
|-----|---------|-----------|--------|
| **Google Maps Platform** | Outdoor campus routing, Geocoding, Street View | $200/month credit | [console.cloud.google.com](https://console.cloud.google.com) |
| **Mapbox** | Indoor map rendering, custom campus tiles | 50K loads/month free | [mapbox.com](https://mapbox.com) |

### OPTIONAL (Future Phases)
| API | Purpose | Notes |
|-----|---------|-------|
| **Firebase Cloud Messaging** | Push notifications for class alerts | Free tier generous |
| **VIT VTOP ERP API** | Live timetable & room occupancy sync | Requires VIT approval |
| **IndoorAtlas / HERE Indoor** | WiFi/BLE beacon indoor positioning (RTLS) | Paid, enterprise |
| **Twilio** | SMS navigation alerts | Pay-per-use |
| **OpenAI API** | Smart destination suggestions (FR6.2) | $0.002/1K tokens |

---

## 📡 API Reference

### Authentication
```
POST /api/auth/register   Body: {name, email, password, vitId, role, department}
POST /api/auth/login      Body: {email, password}  → returns JWT token
GET  /api/auth/me         Header: Authorization: Bearer <token>
PATCH /api/auth/preferences  Body: {defaultRouteType, voiceNavigation, theme}
```

### Buildings (FR1)
```
GET  /api/buildings              ?school=SCOPE|SELECT|SMEC|SENSE
GET  /api/buildings/:id          Full building with rooms by floor
GET  /api/buildings/:id/floorplan/:floor
```

### Rooms (FR5)
```
GET  /api/rooms                  ?building=ID&floor=N&type=classroom,lab
GET  /api/rooms/:id              POI details (capacity, equipment, faculty)
GET  /api/rooms/:id/schedule     Today's timetable
```

### Search (FR2)
```
GET  /api/search?q=CSE204        Fuzzy search rooms, buildings, courses
GET  /api/search/autocomplete?q=CS  Live autocomplete suggestions
```

### Navigation (FR3, FR4)
```
GET  /api/navigation/route?from=ID&to=ID&type=fastest|shortest|wheelchair
GET  /api/navigation/nearby?roomId=ID&types=canteen,washroom
POST /api/navigation/session     Start tracking a navigation session
GET  /api/navigation/history     User's past 20 routes with time saved
```

### Bookmarks (FR6.1)
```
GET    /api/bookmarks            List (max 20 per user)
POST   /api/bookmarks            Body: {roomId, customName, icon, color}
PATCH  /api/bookmarks/:id        Rename/restyle
DELETE /api/bookmarks/:id        Remove bookmark
```

### Analytics (FR7.3)
```
GET  /api/analytics/overview     Admin: total users, trips, time saved
GET  /api/analytics/peak-traffic Admin: busiest rooms & routes
GET  /api/analytics/suggestions  User: smart destination suggestions (FR6.2)
```

### Admin (FR7)
```
POST  /api/admin/buildings                Create building
PUT   /api/admin/buildings/:id            Update building
PATCH /api/admin/buildings/:id/closure   Set construction status
POST  /api/admin/rooms                    Create room
PUT   /api/admin/rooms/:id                Update room
PATCH /api/admin/rooms/:id/closure       Temporarily close room
POST  /api/admin/paths                    Add path segment to graph
PATCH /api/admin/paths/:id/block         Block path (FR3.3)
GET   /api/admin/users                    List all users
```

---

## 🗺️ SRS Requirements Coverage

| SRS Requirement | Implementation |
|----------------|---------------|
| FR1 - Map Visualization | Leaflet.js with building markers, color per school |
| FR2 - Location Search | `/api/search` with fuzzy regex + autocomplete |
| FR3 - Route Computation | A* algorithm in `navigationController.js` |
| FR3.2 - 3 Route Types | fastest / shortest / wheelchair-friendly |
| FR3.3 - Avoid closures | PathSegment.isBlocked filter in A* |
| FR4 - Turn-by-Turn | Navigation.js with step announcements |
| FR4.1 - Voice Nav | Web Speech API (SpeechSynthesisUtterance) |
| FR5 - Building Intelligence | Room modal with capacity, equipment, schedule |
| FR5.3 - Faculty profiles | facultyAssigned field with User populate |
| FR6.1 - Bookmarks (20 max) | enforced in POST /api/bookmarks |
| FR6.2 - Smart suggestions | /api/analytics/suggestions (visit tracking) |
| FR6.3 - Route history | NavigationSession model with timeSaved |
| FR7 - Admin CRUD | /api/admin/* with role guard |
| FR7.3 - Analytics | /api/analytics/overview + peak-traffic |
| FR8 - Error Handling | Graceful degradation, offline-friendly |
| NFR - JWT Auth | jsonwebtoken with role-based access |
| NFR - Rate Limiting | express-rate-limit middleware |
| NFR - HTTPS-ready | helmet.js security headers |

---

## 🔧 Environment Variables

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/rtvmns
JWT_SECRET=your_super_secret_key_change_this
JWT_EXPIRES_IN=7d

# Google Maps (for outdoor routing and geocoding)
GOOGLE_MAPS_API_KEY=AIza...

# Mapbox (for indoor maps and custom campus tiles)
MAPBOX_ACCESS_TOKEN=pk.eyJ1...

# Firebase (optional - push notifications)
FIREBASE_SERVER_KEY=AAAA...

# Rate limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX=100

# CORS
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5500
```

---

## 🏗️ Technology Stack

| Layer | Technology | Why |
|-------|-----------|-----|
| Frontend Map | Leaflet.js (open source) | Free, powerful, OpenStreetMap support |
| Icons | Ionicons v7 | Consistent, web component icons |
| Backend | Express.js 4 | Lightweight, fast routing |
| Database | MongoDB + Mongoose | Flexible schema, GeoJSON support |
| Auth | JWT + bcryptjs | Stateless, secure |
| Pathfinding | Custom A* | Optimal indoor routing (FR3.1) |
| Voice | Web Speech API | Built-in browser, no API key needed |

---

## 📈 Future Phases (Appendix B)

**Phase 2 (6-12 months):**
- Real-time occupancy via VTOP ERP integration
- WiFi/BLE beacon indoor positioning (RTLS)
- AR navigation overlay (WebXR)
- React Native mobile app

**Phase 3 (12-24 months):**
- AI-powered route prediction (OpenAI/Gemini)
- IoT crowd density sensors
- Multi-campus support (VIT Chennai, AP, Bhopal)
- Accessibility audit mode
